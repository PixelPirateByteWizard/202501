import 'package:flutter/material.dart';
import '../models/upgrade.dart';
import '../utils/constants.dart';

class UpgradeCard extends StatefulWidget {
  final Upgrade upgrade;
  final Function(Upgrade) onSelect;
  final bool isSelected;

  const UpgradeCard({
    Key? key,
    required this.upgrade,
    required this.onSelect,
    this.isSelected = false,
  }) : super(key: key);

  @override
  State<UpgradeCard> createState() => _UpgradeCardState();
}

class _UpgradeCardState extends State<UpgradeCard>
    with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  late Animation<double> _scaleAnimation;
  bool _isHovered = false;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      duration: const Duration(milliseconds: 200),
      vsync: this,
    );

    _scaleAnimation = Tween<double>(begin: 1.0, end: 1.05).animate(
      CurvedAnimation(
        parent: _controller,
        curve: Curves.easeInOut,
      ),
    );
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final isActive = _isHovered || widget.isSelected;

    if (isActive) {
      _controller.forward();
    } else {
      _controller.reverse();
    }

    // Use a ConstrainedBox instead of a fixed SizedBox to make it more responsive
    return LayoutBuilder(builder: (context, constraints) {
      // Determine if we're in a vertical (column) layout
      final isVertical = constraints.maxWidth < 200;

      // Calculate a reasonable height constraint - using aspect ratio of approx 3:4
      final height = isVertical
          ? constraints.maxWidth * 1.5
          : // When displayed in column
          constraints.maxWidth * 1.2; // When displayed in row

      return ConstrainedBox(
        constraints: BoxConstraints(
          minHeight: 180,
          maxHeight: height,
        ),
        child: AnimatedBuilder(
          animation: _controller,
          builder: (context, child) {
            return Transform.scale(
              scale: _scaleAnimation.value,
              child: child,
            );
          },
          child: MouseRegion(
            onEnter: (_) => setState(() => _isHovered = true),
            onExit: (_) => setState(() => _isHovered = false),
            child: GestureDetector(
              onTap: () => widget.onSelect(widget.upgrade),
              child: Card(
                elevation: isActive ? 12 : 8,
                shape: RoundedRectangleBorder(
                  borderRadius: AppConstants.borderRadiusLarge,
                  side: BorderSide(
                    color: isActive
                        ? AppConstants.primaryColor
                        : const Color(0xFF4B5563),
                    width: isActive ? 2 : 1,
                  ),
                ),
                color: Colors.black87.withOpacity(0.8),
                child: Container(
                  decoration: BoxDecoration(
                    borderRadius: AppConstants.borderRadiusLarge,
                    gradient: isActive
                        ? LinearGradient(
                            colors: [
                              Colors.black.withOpacity(0.7),
                              AppConstants.secondaryColor.withOpacity(0.2),
                            ],
                            begin: Alignment.topLeft,
                            end: Alignment.bottomRight,
                          )
                        : null,
                  ),
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    mainAxisSize: MainAxisSize.min, // Only take up needed space
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(
                        widget.upgrade.icon,
                        size: isVertical
                            ? 32
                            : 48, // Smaller icon in vertical layout
                        color: _getColorForEffect(widget.upgrade.effect),
                      ),
                      const SizedBox(height: 12),
                      Text(
                        widget.upgrade.name,
                        style: AppConstants.titleLarge,
                        textAlign: TextAlign.center,
                      ),
                      const SizedBox(height: 8),
                      Flexible(
                        // Make text adaptable
                        child: SingleChildScrollView(
                          // Allow scrolling if text overflows
                          child: Text(
                            widget.upgrade.description,
                            style: AppConstants.bodyMedium.copyWith(
                              color: Colors.grey.shade300,
                            ),
                            textAlign: TextAlign.center,
                          ),
                        ),
                      ),
                      const SizedBox(height: 16),
                      ElevatedButton(
                        onPressed: () => widget.onSelect(widget.upgrade),
                        style: ElevatedButton.styleFrom(
                          backgroundColor: AppConstants.primaryColor,
                          foregroundColor: AppConstants.darkTextColor,
                          padding: EdgeInsets.symmetric(
                            horizontal: isVertical
                                ? 8
                                : 16, // Smaller padding in vertical layout
                            vertical: isVertical ? 6 : 8,
                          ),
                          shape: RoundedRectangleBorder(
                            borderRadius: AppConstants.borderRadiusSmall,
                          ),
                        ),
                        child: const Text('擇此仙緣'),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ),
      );
    });
  }

  Color _getColorForEffect(String effect) {
    switch (effect) {
      case 'bolt_damage':
        return Colors.amber;
      case 'unlock_bullet':
        if (widget.upgrade.value == 0) {
          return Colors.deepOrange; // 火焰
        } else if (widget.upgrade.value == 1) {
          return Colors.lightBlue; // 冰霜
        } else if (widget.upgrade.value == 2) {
          return Colors.purple; // 靈氣
        } else {
          return Colors.teal; // 風暴
        }
      case 'max_health':
      case 'health_regen':
      case 'instant_health':
        return Colors.red;
      case 'damage_reflect':
        return Colors.yellow;
      case 'fire_rate':
        return Colors.green;
      case 'multi_shot':
        return Colors.blueAccent;
      case 'enlightenment_gain':
        return Colors.purpleAccent;
      case 'cultivation_gain':
        return Colors.orange;
      default:
        return AppConstants.primaryColor;
    }
  }
}
