import 'package:flutter/material.dart';
import '../utils/constants.dart';

class CultivationLevel extends StatelessWidget {
  final String level;
  final double progress;
  final bool showLevelUp;

  const CultivationLevel({
    Key? key,
    required this.level,
    required this.progress,
    this.showLevelUp = false,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final levelInfo = _getLevelInfo(level);
    final levelColor = levelInfo['color'] as Color;
    final levelName = levelInfo['name'] as String;
    final levelIcon = levelInfo['icon'] as IconData;

    // Wrap the Stack in a SizedBox to ensure it has definite size constraints
    return SizedBox(
      width: double.infinity, // Full width available
      child: Stack(
        clipBehavior: Clip.none,
        children: [
          // 主容器
          Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: Colors.black54,
              borderRadius: BorderRadius.circular(15),
              border: Border.all(
                color: levelColor.withOpacity(0.6),
                width: 1.5,
              ),
              boxShadow: [
                BoxShadow(
                  color: levelColor.withOpacity(0.3),
                  blurRadius: 8,
                  spreadRadius: 2,
                ),
              ],
            ),
            // Add content inside container
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Row(
                      children: [
                        Icon(
                          levelIcon,
                          color: levelColor,
                          size: 24,
                        ),
                        const SizedBox(width: 8),
                        Text(
                          levelName,
                          style: AppConstants.headlineMedium.copyWith(
                            color: levelColor,
                            fontSize: 22, // Smaller than default headlineMedium
                          ),
                        ),
                      ],
                    ),
                    if (showLevelUp)
                      Container(
                        padding: const EdgeInsets.symmetric(
                          horizontal: 8,
                          vertical: 4,
                        ),
                        decoration: BoxDecoration(
                          color: Colors.amber.withOpacity(0.3),
                          borderRadius: BorderRadius.circular(12),
                          border: Border.all(
                            color: Colors.amber,
                            width: 1,
                          ),
                        ),
                        child: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            const Icon(
                              Icons.arrow_upward,
                              color: Colors.amber,
                              size: 16,
                            ),
                            const SizedBox(width: 4),
                            Text(
                              '突破',
                              style: AppConstants.bodyMedium.copyWith(
                                color: Colors.amber,
                                fontWeight: FontWeight.bold,
                                fontSize: 12, // Smaller than default bodyMedium
                              ),
                            ),
                          ],
                        ),
                      ),
                  ],
                ),
                const SizedBox(height: 8),
                LinearProgressIndicator(
                  value: progress,
                  backgroundColor: Colors.grey.shade700,
                  valueColor: AlwaysStoppedAnimation<Color>(levelColor),
                  minHeight: 4,
                  borderRadius: BorderRadius.circular(2),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // 獲取等級相關資訊
  Map<String, dynamic> _getLevelInfo(String level) {
    switch (level) {
      case '煉氣期':
        return {
          'name': '煉氣期',
          'color': Colors.green.shade400,
          'icon': Icons.filter_vintage,
        };
      case '築基期':
        return {
          'name': '築基期',
          'color': Colors.blue.shade400,
          'icon': Icons.foundation,
        };
      case '結丹期':
        return {
          'name': '結丹期',
          'color': Colors.purple.shade400,
          'icon': Icons.science,
        };
      case '元嬰期':
        return {
          'name': '元嬰期',
          'color': Colors.deepPurple.shade400,
          'icon': Icons.child_care,
        };
      case '化神期':
        return {
          'name': '化神期',
          'color': Colors.red.shade400,
          'icon': Icons.auto_fix_high,
        };
      case '煉虛期':
        return {
          'name': '煉虛期',
          'color': Colors.amber.shade400,
          'icon': Icons.whatshot,
        };
      case '大乘期':
        return {
          'name': '大乘期',
          'color': Colors.orange.shade400,
          'icon': Icons.brightness_7,
        };
      case '渡劫期':
        return {
          'name': '渡劫期',
          'color': Colors.deepOrange.shade400,
          'icon': Icons.flash_on,
        };
      default:
        return {
          'name': '無',
          'color': Colors.grey.shade400,
          'icon': Icons.question_mark,
        };
    }
  }
}
