import 'package:flutter/material.dart';
import '../utils/constants.dart';
import '../services/audio_service.dart';
import '../services/vibration_service.dart';
import '../services/storage_service.dart';
import 'game_screen.dart';

class MainMenuScreen extends StatefulWidget {
  const MainMenuScreen({Key? key}) : super(key: key);

  @override
  State<MainMenuScreen> createState() => _MainMenuScreenState();
}

class _MainMenuScreenState extends State<MainMenuScreen>
    with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  late Animation<double> _fadeAnimation;

  // 服務實例
  final AudioService _audioService = AudioService();
  final VibrationService _vibrationService = VibrationService();

  // 設置狀態
  bool _isMusicEnabled = true;
  bool _isSoundEnabled = true;
  bool _isVibrationEnabled = true;

  // 高分記錄
  int _highScore = 0;
  int _maxWave = 0;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      duration: const Duration(milliseconds: 1500),
      vsync: this,
    );

    _fadeAnimation = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(
        parent: _controller,
        curve: Curves.easeOut,
      ),
    );

    _controller.forward();
    _initServices();
  }

  Future<void> _initServices() async {
    // 初始化音頻服務
    await _audioService.init();

    // 初始化振動服務
    await _vibrationService.init();

    // 讀取設置
    final settings = await StorageService.loadSettings();

    // 讀取最高分和最高波數
    final highScore = await StorageService.loadHighScore();
    final maxWave = await StorageService.loadMaxWave();

    setState(() {
      _isMusicEnabled = settings['musicEnabled'] as bool;
      _isSoundEnabled = settings['soundEnabled'] as bool;
      _isVibrationEnabled = settings['vibrationEnabled'] as bool;
      _highScore = highScore;
      _maxWave = maxWave;
    });

    // 播放菜單音樂
    _audioService.playMenuMusic();
  }

  Future<void> _updateSettings() async {
    // 更新設置
    await _audioService.setMusicEnabled(_isMusicEnabled);
    await _audioService.setSoundEnabled(_isSoundEnabled);
    await _vibrationService.setVibrationEnabled(_isVibrationEnabled);

    // 保存設置
    await StorageService.saveSettings({
      'musicEnabled': _isMusicEnabled,
      'soundEnabled': _isSoundEnabled,
      'vibrationEnabled': _isVibrationEnabled,
      'difficulty': 'normal', // 默認難度
    });
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  void _startGame() {
    if (_isSoundEnabled) {
      _audioService.playSound('button_click');
    }

    if (_isVibrationEnabled) {
      _vibrationService.shortVibrate();
    }

    Navigator.push(
      context,
      MaterialPageRoute(builder: (context) => const GameScreen()),
    );
  }

  void _showSettingsDialog() {
    if (_isSoundEnabled) {
      _audioService.playSound('button_click');
    }

    if (_isVibrationEnabled) {
      _vibrationService.shortVibrate();
    }

    showDialog(
      context: context,
      builder: (context) => _buildSettingsDialog(),
    );
  }

  void _showInstructionsDialog() {
    if (_isSoundEnabled) {
      _audioService.playSound('button_click');
    }

    if (_isVibrationEnabled) {
      _vibrationService.shortVibrate();
    }

    showDialog(
      context: context,
      builder: (context) => _buildInstructionsDialog(),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(
          gradient: AppConstants.startScreenGradient,
        ),
        child: AnimatedBuilder(
          animation: _fadeAnimation,
          builder: (context, child) {
            return Opacity(
              opacity: _fadeAnimation.value,
              child: child,
            );
          },
          child: Center(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                // 遊戲標題
                _buildGameTitle(),

                const SizedBox(height: 40),

                // 最高分和最高波數
                _buildStats(),

                const SizedBox(height: 40),

                // 開始遊戲按鈕
                _buildMenuButton(
                  icon: Icons.play_arrow,
                  label: '開始修煉',
                  onTap: _startGame,
                  isLarge: true,
                ),

                const SizedBox(height: 20),

                // 設置和說明按鈕
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    _buildMenuButton(
                      icon: Icons.settings,
                      label: '設置',
                      onTap: _showSettingsDialog,
                    ),
                    const SizedBox(width: 20),
                    _buildMenuButton(
                      icon: Icons.help_outline,
                      label: '修煉心法',
                      onTap: _showInstructionsDialog,
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildGameTitle() {
    return Column(
      children: [
        // 主標題
        Text(
          '仙途玄防',
          style: AppConstants.headlineLarge.copyWith(
            fontSize: 60,
            fontWeight: FontWeight.w900,
            letterSpacing: 2,
          ),
        ),

        const SizedBox(height: 8),

        // 副標題
        Text(
          '太虛爭鋒，逆天成仙',
          style: AppConstants.headlineMedium.copyWith(
            fontSize: 24,
            fontWeight: FontWeight.w500,
            color: Colors.amber.shade300,
          ),
        ),
      ],
    );
  }

  Widget _buildStats() {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
      decoration: BoxDecoration(
        color: Colors.black38,
        borderRadius: BorderRadius.circular(15),
        border: Border.all(color: AppConstants.primaryColor.withOpacity(0.3)),
      ),
      child: Column(
        children: [
          Text(
            '修煉記錄',
            style: AppConstants.titleLarge.copyWith(
              color: Colors.amber.shade300,
            ),
          ),
          const SizedBox(height: 8),
          Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(Icons.trending_up, color: Colors.amber.shade400, size: 20),
              const SizedBox(width: 8),
              Text(
                '最高修為: $_highScore',
                style: AppConstants.bodyLarge,
              ),
              const SizedBox(width: 20),
              Icon(Icons.warning_amber, color: Colors.amber.shade400, size: 20),
              const SizedBox(width: 8),
              Text(
                '最高劫數: $_maxWave',
                style: AppConstants.bodyLarge,
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildMenuButton({
    required IconData icon,
    required String label,
    required VoidCallback onTap,
    bool isLarge = false,
  }) {
    return ElevatedButton(
      onPressed: onTap,
      style: ElevatedButton.styleFrom(
        backgroundColor: AppConstants.primaryColor,
        foregroundColor: AppConstants.darkTextColor,
        padding: EdgeInsets.symmetric(
          horizontal: isLarge ? 40 : 24,
          vertical: isLarge ? 16 : 12,
        ),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(isLarge ? 30 : 20),
        ),
        elevation: isLarge ? 8 : 4,
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(
            icon,
            size: isLarge ? 28 : 20,
            color: Colors.brown.shade800,
          ),
          SizedBox(width: isLarge ? 12 : 8),
          Text(
            label,
            style: TextStyle(
              fontSize: isLarge ? 24 : 16,
              fontWeight: FontWeight.bold,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSettingsDialog() {
    // 創建一個暫存的設置狀態
    bool tempMusicEnabled = _isMusicEnabled;
    bool tempSoundEnabled = _isSoundEnabled;
    bool tempVibrationEnabled = _isVibrationEnabled;

    return StatefulBuilder(
      builder: (context, setState) {
        return AlertDialog(
          backgroundColor: Colors.black87,
          title: Text(
            '設置',
            style: AppConstants.titleLarge,
            textAlign: TextAlign.center,
          ),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              _buildSettingToggle(
                icon: Icons.music_note,
                label: '背景音樂',
                value: tempMusicEnabled,
                onChanged: (value) {
                  setState(() {
                    tempMusicEnabled = value;
                  });
                },
              ),
              const SizedBox(height: 16),
              _buildSettingToggle(
                icon: Icons.volume_up,
                label: '音效',
                value: tempSoundEnabled,
                onChanged: (value) {
                  setState(() {
                    tempSoundEnabled = value;
                  });

                  // 如果啟用音效，播放按鈕音效
                  if (value) {
                    _audioService.playSound('button_click');
                  }
                },
              ),
              const SizedBox(height: 16),
              _buildSettingToggle(
                icon: Icons.vibration,
                label: '振動',
                value: tempVibrationEnabled,
                onChanged: (value) {
                  setState(() {
                    tempVibrationEnabled = value;
                  });

                  // 如果啟用振動，觸發振動
                  if (value) {
                    _vibrationService.shortVibrate();
                  }
                },
              ),
            ],
          ),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.pop(context);
              },
              style: TextButton.styleFrom(
                foregroundColor: Colors.grey,
              ),
              child: const Text('取消'),
            ),
            ElevatedButton(
              onPressed: () {
                // 應用新設置
                this.setState(() {
                  _isMusicEnabled = tempMusicEnabled;
                  _isSoundEnabled = tempSoundEnabled;
                  _isVibrationEnabled = tempVibrationEnabled;
                });

                _updateSettings();
                Navigator.pop(context);
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: AppConstants.primaryColor,
                foregroundColor: AppConstants.darkTextColor,
              ),
              child: const Text('確定'),
            ),
          ],
        );
      },
    );
  }

  Widget _buildSettingToggle({
    required IconData icon,
    required String label,
    required bool value,
    required ValueChanged<bool> onChanged,
  }) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Row(
          children: [
            Icon(
              icon,
              color: value ? AppConstants.primaryColor : Colors.grey,
              size: 24,
            ),
            const SizedBox(width: 12),
            Text(
              label,
              style: AppConstants.bodyLarge,
            ),
          ],
        ),
        Switch(
          value: value,
          onChanged: onChanged,
          activeColor: AppConstants.primaryColor,
        ),
      ],
    );
  }

  Widget _buildInstructionsDialog() {
    return AlertDialog(
      backgroundColor: Colors.black87,
      title: Text(
        '修煉心法',
        style: AppConstants.titleLarge,
        textAlign: TextAlign.center,
      ),
      content: Container(
        constraints: const BoxConstraints(maxWidth: 400),
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              _buildInstructionSection(
                title: '遊戲目標',
                content: '擊退各路妖魔，提升修為，突破劫數，踏上成仙之路。',
              ),
              _buildInstructionSection(
                title: '基本操作',
                content: '角色固定在中央位置，敵人從四周出現。角色會自動向最近的敵人發射法術。',
              ),
              _buildInstructionSection(
                title: '修為與悟道',
                content: '擊敗敵人獲得修為，修為累積提升角色境界。悟道進度滿後可進行頓悟，獲得新的能力。',
              ),
              _buildInstructionSection(
                title: '法術種類',
                content:
                    '雷電：基礎法術，可造成暈眩\n火焰：持續灼燒效果\n冰霜：減緩敵人速度\n靈氣：穿透多個敵人\n風暴：擊退敵人',
              ),
              _buildInstructionSection(
                title: '敵人類型',
                content:
                    '鬼煞：速度快但脆弱，有機率閃避\n妖獸：強壯但緩慢，有傷害減免\n邪修：平衡型，可召喚分身\n怨魂：高傷害，可短暫無敵\n魔王：強大的Boss，憤怒時傷害提升',
              ),
              _buildInstructionSection(
                title: '連擊系統',
                content: '連續擊敗敵人可提高連擊數，增加獲得的修為加成',
              ),
              _buildInstructionSection(
                title: '劫數',
                content: '每五波出現一次魔王，擊敗後進入下一劫，難度提升',
              ),
            ],
          ),
        ),
      ),
      actions: [
        ElevatedButton(
          onPressed: () {
            Navigator.pop(context);
          },
          style: ElevatedButton.styleFrom(
            backgroundColor: AppConstants.primaryColor,
            foregroundColor: AppConstants.darkTextColor,
          ),
          child: const Text('瞭解'),
        ),
      ],
    );
  }

  Widget _buildInstructionSection({
    required String title,
    required String content,
  }) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            title,
            style: AppConstants.bodyLarge.copyWith(
              color: AppConstants.primaryColor,
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 6),
          Text(
            content,
            style: AppConstants.bodyMedium,
          ),
        ],
      ),
    );
  }
}
