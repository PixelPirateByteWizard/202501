import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'character_select_screen.dart';
import 'achievements_screen.dart';
import 'settings_screen.dart';
import '../taifangIAP/LinstStoreView.dart';
import '../taifangIAP/SkillShopView.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({Key? key}) : super(key: key);

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen>
    with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  late Animation<double> _fadeAnimation;

  @override
  void initState() {
    super.initState();
    // 设置横屏
    SystemChrome.setPreferredOrientations([
      DeviceOrientation.landscapeLeft,
      DeviceOrientation.landscapeRight,
    ]);

    _controller = AnimationController(
      duration: const Duration(milliseconds: 1500),
      vsync: this,
    );

    _fadeAnimation = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(
        parent: _controller,
        curve: Curves.easeOut,
      ),
    );

    _controller.forward();
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  void _navigateToCharacterSelect() {
    Navigator.push(
      context,
      PageRouteBuilder(
        pageBuilder: (_, __, ___) => const CharacterSelectScreen(),
        transitionsBuilder: (_, animation, __, child) {
          return FadeTransition(
            opacity: animation,
            child: child,
          );
        },
        transitionDuration: const Duration(milliseconds: 500),
      ),
    );
  }

  void _navigateToAchievements() {
    Navigator.push(
      context,
      PageRouteBuilder(
        pageBuilder: (_, __, ___) => const AchievementsScreen(),
        transitionsBuilder: (_, animation, __, child) {
          return FadeTransition(
            opacity: animation,
            child: child,
          );
        },
        transitionDuration: const Duration(milliseconds: 500),
      ),
    );
  }

  void _navigateToSettings() {
    Navigator.push(
      context,
      PageRouteBuilder(
        pageBuilder: (_, __, ___) => const SettingsScreen(),
        transitionsBuilder: (_, animation, __, child) {
          return FadeTransition(
            opacity: animation,
            child: child,
          );
        },
        transitionDuration: const Duration(milliseconds: 500),
      ),
    );
  }

  void _navigateToStore() {
    Navigator.push(
      context,
      PageRouteBuilder(
        pageBuilder: (_, __, ___) => const LinstStoreView(),
        transitionsBuilder: (_, animation, __, child) {
          return FadeTransition(
            opacity: animation,
            child: child,
          );
        },
        transitionDuration: const Duration(milliseconds: 500),
      ),
    );
  }

  void _navigateToSkillShop() {
    Navigator.push(
      context,
      PageRouteBuilder(
        pageBuilder: (_, __, ___) => const SkillShopView(),
        transitionsBuilder: (_, animation, __, child) {
          return FadeTransition(
            opacity: animation,
            child: child,
          );
        },
        transitionDuration: const Duration(milliseconds: 500),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(
          image: DecorationImage(
            image: AssetImage('assets/images/backgrounds/backgrounds_2.png'),
            fit: BoxFit.cover,
          ),
        ),
        child: SafeArea(
          child: AnimatedBuilder(
            animation: _fadeAnimation,
            builder: (context, child) {
              return Opacity(
                opacity: _fadeAnimation.value,
                child: child,
              );
            },
            child: SingleChildScrollView(
              physics: const BouncingScrollPhysics(),
              child: Center(
                child: Padding(
                  padding: const EdgeInsets.symmetric(vertical: 30),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      // 游戏标题
                      _buildGameTitle(),

                      const SizedBox(height: 60),

                      // 主菜单按钮
                      _buildMenuButton(
                        icon: Icons.play_arrow_rounded,
                        label: '開始遊戲',
                        onTap: _navigateToCharacterSelect,
                        isPrimary: true,
                      ),

                      const SizedBox(height: 24),

                      _buildMenuButton(
                        icon: Icons.emoji_events_rounded,
                        label: '成就系統',
                        onTap: _navigateToAchievements,
                      ),

                      const SizedBox(height: 24),

                      _buildMenuButton(
                        icon: Icons.settings_rounded,
                        label: '遊戲設置',
                        onTap: _navigateToSettings,
                      ),

                      const SizedBox(height: 24),

                      _buildMenuButton(
                        icon: Icons.shopping_cart_rounded,
                        label: '仙玉商城',
                        onTap: _navigateToStore,
                      ),

                      const SizedBox(height: 24),

                      _buildMenuButton(
                        icon: Icons.auto_awesome,
                        label: '技能道具商城',
                        onTap: _navigateToSkillShop,
                      ),

                      const SizedBox(height: 40),

                      // 版本信息
                      Text(
                        '版本 1.0.0',
                        style: TextStyle(
                          color: Colors.white.withOpacity(0.6),
                          fontSize: 12,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildGameTitle() {
    return Column(
      children: [
        // 主标题
        Text(
          '仙途玄防',
          style: Theme.of(context).textTheme.headlineLarge!.copyWith(
            fontSize: 60,
            fontWeight: FontWeight.w900,
            letterSpacing: 2,
            shadows: [
              Shadow(
                color: Colors.black.withOpacity(0.7),
                blurRadius: 10,
                offset: const Offset(2, 2),
              ),
            ],
          ),
        ),

        const SizedBox(height: 8),

        // 副标题
        Text(
          '太虛爭鋒，逆天成仙',
          style: Theme.of(context).textTheme.headlineMedium!.copyWith(
            fontSize: 24,
            fontWeight: FontWeight.w500,
            color: Colors.amber.shade300,
            shadows: [
              Shadow(
                color: Colors.black.withOpacity(0.7),
                blurRadius: 5,
                offset: const Offset(1, 1),
              ),
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildMenuButton({
    required IconData icon,
    required String label,
    required VoidCallback onTap,
    bool isPrimary = false,
  }) {
    return Container(
      width: 280,
      height: isPrimary ? 64 : 56,
      margin: const EdgeInsets.symmetric(horizontal: 20),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: isPrimary
              ? [Colors.amber.shade700, Colors.amber.shade400]
              : [
                  Colors.blueGrey.shade800.withOpacity(0.8),
                  Colors.blueGrey.shade600.withOpacity(0.8)
                ],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(isPrimary ? 32 : 28),
        boxShadow: [
          BoxShadow(
            color: isPrimary
                ? Colors.amber.withOpacity(0.4)
                : Colors.black.withOpacity(0.4),
            blurRadius: 8,
            offset: const Offset(0, 4),
          ),
        ],
        border: Border.all(
          color: isPrimary
              ? Colors.amber.shade300
              : Colors.blueGrey.shade400.withOpacity(0.5),
          width: 1.5,
        ),
      ),
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          onTap: onTap,
          borderRadius: BorderRadius.circular(isPrimary ? 32 : 28),
          splashColor: isPrimary
              ? Colors.amber.withOpacity(0.3)
              : Colors.blueGrey.withOpacity(0.3),
          highlightColor: Colors.transparent,
          child: Center(
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(
                  icon,
                  color: isPrimary ? Colors.white : Colors.amber.shade200,
                  size: isPrimary ? 28 : 24,
                ),
                const SizedBox(width: 12),
                Text(
                  label,
                  style: TextStyle(
                    color: isPrimary ? Colors.white : Colors.amber.shade200,
                    fontSize: isPrimary ? 20 : 18,
                    fontWeight: FontWeight.bold,
                    letterSpacing: 1,
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
