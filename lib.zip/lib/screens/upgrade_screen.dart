import 'package:flutter/material.dart';
import '../components/upgrade_card.dart';
import '../models/player.dart';
import '../models/upgrade.dart';
import '../utils/constants.dart';

class UpgradeScreen extends StatefulWidget {
  final Player player;
  final Function(Upgrade) onUpgradeSelected;

  const UpgradeScreen({
    Key? key,
    required this.player,
    required this.onUpgradeSelected,
  }) : super(key: key);

  @override
  State<UpgradeScreen> createState() => _UpgradeScreenState();
}

class _UpgradeScreenState extends State<UpgradeScreen>
    with SingleTickerProviderStateMixin {
  late List<Upgrade> _upgradeOptions;
  late AnimationController _controller;
  late Animation<double> _fadeAnimation;
  Upgrade? _selectedUpgrade;

  @override
  void initState() {
    super.initState();
    // 生成三個升級選項
    _upgradeOptions = Upgrade.generateUpgradeOptions(
      widget.player.bullets,
      widget.player.cultivationLevel,
      widget.player.passiveSkills, // Using passiveSkills as acquiredUpgrades
    );

    // 設置動畫
    _controller = AnimationController(
      duration: const Duration(milliseconds: 800),
      vsync: this,
    );

    _fadeAnimation = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(
        parent: _controller,
        curve: Curves.easeOut,
      ),
    );

    _controller.forward();
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.transparent,
      body: SafeArea(
        child: Container(
          decoration: const BoxDecoration(
            gradient: AppConstants.upgradeScreenGradient,
          ),
          child: AnimatedBuilder(
            animation: _fadeAnimation,
            builder: (context, child) {
              return Opacity(
                opacity: _fadeAnimation.value,
                child: child,
              );
            },
            child: SingleChildScrollView(
              child: ConstrainedBox(
                constraints: BoxConstraints(
                  minHeight: MediaQuery.of(context).size.height -
                      MediaQuery.of(context).padding.top -
                      MediaQuery.of(context).padding.bottom,
                ),
                child: Center(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      const SizedBox(height: 20),
                      Text(
                        '仙緣三擇',
                        style: AppConstants.headlineMedium,
                      ),
                      const SizedBox(height: 16),
                      Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 16.0),
                        child: Text(
                          '選擇一項仙緣增強你的能力',
                          style: AppConstants.bodyLarge.copyWith(
                            color: Colors.purple.shade200,
                          ),
                          textAlign: TextAlign.center,
                        ),
                      ),
                      const SizedBox(height: 24),
                      _buildUpgradeCards(),
                      const SizedBox(height: 24),
                      AnimatedOpacity(
                        opacity: _selectedUpgrade != null ? 1.0 : 0.0,
                        duration: const Duration(milliseconds: 300),
                        child: Padding(
                          padding: const EdgeInsets.symmetric(horizontal: 16.0),
                          child: Text(
                            _selectedUpgrade != null
                                ? '你選擇了：${_selectedUpgrade!.name}'
                                : '',
                            style: AppConstants.bodyLarge.copyWith(
                              color: Colors.amber.shade300,
                            ),
                            textAlign: TextAlign.center,
                          ),
                        ),
                      ),
                      const SizedBox(height: 20),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildUpgradeCards() {
    return LayoutBuilder(
      builder: (context, constraints) {
        // 根據屏幕寬度計算卡片寬度
        final screenWidth = MediaQuery.of(context).size.width;
        final cardWidth = screenWidth > 900
            ? 250.0
            : (screenWidth - 64) / _upgradeOptions.length;

        // Responsively adjust for smaller screens or landscape mode
        final isLandscape =
            MediaQuery.of(context).orientation == Orientation.landscape;
        final isSmallScreen = screenWidth < 600;

        // Use a Column for small screens in portrait mode, Row otherwise
        if (isSmallScreen && !isLandscape) {
          return Column(
            children: _upgradeOptions.map((upgrade) {
              return Container(
                width: cardWidth * 1.2,
                margin: const EdgeInsets.only(bottom: 16),
                child: UpgradeCard(
                  upgrade: upgrade,
                  isSelected: _selectedUpgrade == upgrade,
                  onSelect: (selectedUpgrade) {
                    setState(() {
                      _selectedUpgrade = selectedUpgrade;
                    });

                    // 短暫延遲後返回並應用升級
                    Future.delayed(const Duration(milliseconds: 500), () {
                      if (mounted) {
                        widget.onUpgradeSelected(selectedUpgrade);
                      }
                    });
                  },
                ),
              );
            }).toList(),
          );
        }

        // Use Row for landscape or larger screens
        return Center(
          child: Container(
            constraints: const BoxConstraints(maxWidth: 900),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: List.generate(_upgradeOptions.length, (index) {
                return Container(
                  width: cardWidth,
                  margin: const EdgeInsets.symmetric(horizontal: 8),
                  child: UpgradeCard(
                    upgrade: _upgradeOptions[index],
                    isSelected: _selectedUpgrade == _upgradeOptions[index],
                    onSelect: (upgrade) {
                      setState(() {
                        _selectedUpgrade = upgrade;
                      });

                      // 短暫延遲後返回並應用升級
                      Future.delayed(const Duration(milliseconds: 500), () {
                        if (mounted) {
                          widget.onUpgradeSelected(upgrade);
                        }
                      });
                    },
                  ),
                );
              }),
            ),
          ),
        );
      },
    );
  }
}
