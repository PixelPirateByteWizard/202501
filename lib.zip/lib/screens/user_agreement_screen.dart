import 'package:flutter/material.dart';

class UserAgreementScreen extends StatelessWidget {
  const UserAgreementScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(
          image: DecorationImage(
            image: AssetImage('assets/images/backgrounds/backgrounds_5.png'),
            fit: BoxFit.cover,
          ),
        ),
        child: SafeArea(
          child: Column(
            children: [
              _buildHeader(context),
              Expanded(
                child: _buildContent(),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildHeader(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 16, horizontal: 8),
      child: Row(
        children: [
          IconButton(
            onPressed: () => Navigator.pop(context),
            icon: const Icon(
              Icons.arrow_back_ios_new,
              color: Colors.white,
            ),
          ),
          const SizedBox(width: 8),
          const Text(
            '用戶協議',
            style: TextStyle(
              color: Colors.white,
              fontSize: 24,
              fontWeight: FontWeight.bold,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildContent() {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Container(
        padding: const EdgeInsets.all(20),
        decoration: BoxDecoration(
          color: Colors.black.withOpacity(0.7),
          borderRadius: BorderRadius.circular(16),
          border: Border.all(
            color: Colors.amber.withOpacity(0.3),
            width: 1,
          ),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _buildSection(
              '協議概述',
              '歡迎您使用仙俠逃方遊戲！為了保護您的權益，請在使用我們的服務前仔細閱讀本協議。通過使用本遊戲，即表示您同意接受本協議的所有條款和條件。',
            ),
            const SizedBox(height: 24),
            _buildSection(
              '賬號註冊',
              '''1. 您必須提供真實、準確、完整的個人資料。
2. 您必須妥善保管自己的賬號和密碼。
3. 未經允許，不得將賬號轉讓或出售給他人。
4. 一個賬號只能由一個用戶使用。''',
            ),
            const SizedBox(height: 24),
            _buildSection(
              '用戶行為規範',
              '''1. 禁止使用外掛、腳本等第三方工具。
2. 禁止利用遊戲漏洞謀取利益。
3. 禁止發布違法、違規、色情等不當內容。
4. 禁止騷擾、侮辱其他玩家。
5. 禁止進行任何形式的遊戲幣、裝備等實物交易。''',
            ),
            const SizedBox(height: 24),
            _buildSection(
              '虛擬物品和遊戲幣',
              '''1. 遊戲內所有虛擬物品的所有權歸遊戲公司所有。
2. 用戶只擁有虛擬物品的使用權。
3. 遊戲幣不可兌換為現實貨幣。
4. 遊戲公司保留調整虛擬物品屬性的權利。''',
            ),
            const SizedBox(height: 24),
            _buildSection(
              '付費服務',
              '''1. 充值前請確認自己的支付能力。
2. 所有支付均為一次性且不可退款。
3. 未成年人請在監護人同意下進行充值。
4. 如遇支付問題，請及時聯繫客服。''',
            ),
            const SizedBox(height: 24),
            _buildSection(
              '隱私保護',
              '''1. 我們會依法保護您的個人信息。
2. 未經您的同意，不會向第三方披露您的信息。
3. 我們會採取合理措施保護您的賬號安全。
4. 具體隱私政策請參考《隱私政策》文件。''',
            ),
            const SizedBox(height: 24),
            _buildSection(
              '免責聲明',
              '''1. 因不可抗力導致的服務中斷，本公司不承擔責任。
2. 用戶因違反協議造成的損失由用戶自行承擔。
3. 遊戲內容可能會不定期更新或調整。
4. 本公司保留對本協議進行修改的權利。''',
            ),
            const SizedBox(height: 24),
            _buildSection(
              '協議變更',
              '我們保留隨時修改本協議的權利。協議修改後，我們會在遊戲內或官方網站公布修改內容。如果您繼續使用我們的服務，即表示您接受修改後的協議。',
            ),
            const SizedBox(height: 24),
            _buildSection(
              '聯繫方式',
              '''如果您對本協議有任何疑問，請通過以下方式聯繫我們：
• 客服郵箱：support@xianxiataifang.com
• 官方網站：www.xianxiataifang.com
• 客服電話：+886-XX-XXXXXXXX''',
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildSection(String title, String content) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            Container(
              width: 4,
              height: 18,
              decoration: BoxDecoration(
                color: Colors.amber,
                borderRadius: BorderRadius.circular(2),
              ),
            ),
            const SizedBox(width: 8),
            Text(
              title,
              style: const TextStyle(
                color: Colors.amber,
                fontSize: 18,
                fontWeight: FontWeight.bold,
              ),
            ),
          ],
        ),
        const SizedBox(height: 16),
        Text(
          content,
          style: TextStyle(
            color: Colors.white.withOpacity(0.7),
            fontSize: 14,
            height: 1.6,
          ),
        ),
      ],
    );
  }
}
