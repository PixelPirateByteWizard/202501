import 'package:flutter/material.dart';

class AboutAppScreen extends StatelessWidget {
  const AboutAppScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(
          image: DecorationImage(
            image: AssetImage('assets/images/backgrounds/backgrounds_5.png'),
            fit: BoxFit.cover,
          ),
        ),
        child: SafeArea(
          child: Column(
            children: [
              _buildHeader(context),
              Expanded(
                child: _buildContent(),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildHeader(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 16, horizontal: 8),
      child: Row(
        children: [
          IconButton(
            onPressed: () => Navigator.pop(context),
            icon: const Icon(
              Icons.arrow_back_ios_new,
              color: Colors.white,
            ),
          ),
          const SizedBox(width: 8),
          const Text(
            '關於仙俠逃方',
            style: TextStyle(
              color: Colors.white,
              fontSize: 24,
              fontWeight: FontWeight.bold,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildContent() {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Container(
        padding: const EdgeInsets.all(20),
        decoration: BoxDecoration(
          color: Colors.black.withOpacity(0.7),
          borderRadius: BorderRadius.circular(16),
          border: Border.all(
            color: Colors.amber.withOpacity(0.3),
            width: 1,
          ),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _buildAppIcon(),
            const SizedBox(height: 24),
            _buildInfoSection('應用信息', [
              {'title': '版本', 'content': '1.0.0'},
              {'title': '更新日期', 'content': '2024年5月7日'},
              {'title': '開發者', 'content': '仙途工作室'},
            ]),
            const SizedBox(height: 24),
            _buildInfoSection('應用介紹', [
              {'content': '仙俠逃方是一款充滿東方玄幻色彩的修仙遊戲，玩家將在這裡體驗獨特的修仙世界，展開一段精彩的修真之旅。'},
              {'content': '遊戲融合了傳統修仙元素與現代遊戲玩法，為玩家提供身臨其境的修真體驗。'},
            ]),
            const SizedBox(height: 24),
            _buildInfoSection('特色功能', [
              {'content': '• 獨特的修仙世界觀與劇情'},
              {'content': '• 豐富的修煉系統與功法'},
              {'content': '• 多樣化的任務與挑戰'},
              {'content': '• 精美的畫面與音效'},
              {'content': '• 社交互動與競技系統'},
            ]),
            const SizedBox(height: 24),
            _buildInfoSection('聯繫我們', [
              {'title': '官方網站', 'content': 'www.xianxiataifang.com'},
              {'title': '客服郵箱', 'content': 'support@xianxiataifang.com'},
              {'title': '商務合作', 'content': 'business@xianxiataifang.com'},
            ]),
          ],
        ),
      ),
    );
  }

  Widget _buildAppIcon() {
    return Center(
      child: Container(
        width: 100,
        height: 100,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(20),
          boxShadow: [
            BoxShadow(
              color: Colors.amber.withOpacity(0.3),
              blurRadius: 20,
              spreadRadius: 2,
            ),
          ],
        ),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(20),
          child: Image.asset(
            'assets/images/app_icon.png',
            fit: BoxFit.cover,
          ),
        ),
      ),
    );
  }

  Widget _buildInfoSection(String title, List<Map<String, String>> items) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            Container(
              width: 4,
              height: 18,
              decoration: BoxDecoration(
                color: Colors.amber,
                borderRadius: BorderRadius.circular(2),
              ),
            ),
            const SizedBox(width: 8),
            Text(
              title,
              style: const TextStyle(
                color: Colors.amber,
                fontSize: 18,
                fontWeight: FontWeight.bold,
              ),
            ),
          ],
        ),
        const SizedBox(height: 16),
        ...items.map((item) {
          if (item.containsKey('title')) {
            return Padding(
              padding: const EdgeInsets.only(bottom: 12),
              child: Row(
                children: [
                  Text(
                    '${item['title']}: ',
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 15,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                  Expanded(
                    child: Text(
                      item['content']!,
                      style: TextStyle(
                        color: Colors.white.withOpacity(0.7),
                        fontSize: 15,
                      ),
                    ),
                  ),
                ],
              ),
            );
          } else {
            return Padding(
              padding: const EdgeInsets.only(bottom: 12),
              child: Text(
                item['content']!,
                style: TextStyle(
                  color: Colors.white.withOpacity(0.7),
                  fontSize: 15,
                  height: 1.5,
                ),
              ),
            );
          }
        }).toList(),
      ],
    );
  }
}
