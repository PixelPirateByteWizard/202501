import 'package:flutter/material.dart';

class StatsPage extends StatelessWidget {
  const StatsPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Statistics'),
        backgroundColor: const Color(0xFF8FB3B0),
      ),
      body: const Center(
        child: Text(
          'Statistics Coming Soon',
          style: TextStyle(fontSize: 18),
        ),
      ),
    );
  }
}
