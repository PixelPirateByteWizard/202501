import 'package:flutter/material.dart';

class ProfilePage extends StatelessWidget {
  const ProfilePage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Profile'),
        backgroundColor: const Color(0xFF8FB3B0),
      ),
      body: const Center(
        child: Text(
          'Profile Coming Soon',
          style: TextStyle(fontSize: 18),
        ),
      ),
    );
  }
}
