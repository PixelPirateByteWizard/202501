import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'LinstPurchaseManager.dart';
import 'LinstBundle.dart';
import 'dart:ui';
import 'package:in_app_purchase/in_app_purchase.dart';

class LinstStoreView extends StatefulWidget {
  const LinstStoreView({Key? key}) : super(key: key);

  @override
  _LinstStoreViewState createState() => _LinstStoreViewState();
}

class _LinstStoreViewState extends State<LinstStoreView>
    with SingleTickerProviderStateMixin {
  int _coinBalance = 6000;
  final LinstPurchaseManager _shopManager = LinstPurchaseManager.instance;
  late List<LinstBundle> _shopItems;
  Map<String, ProductDetails> _productDetails = {};
  bool _isLoading = true;

  // 定义游戏风格的主题颜色
  static const primaryColor = Color(0xFFFFD700); // 金色
  static const secondaryColor = Color(0xFFFFA500); // 橙色
  static const backgroundColor = Color(0xFF1A1A2F); // 深蓝色背景
  static const surfaceColor = Color(0xFF2A2A40); // 稍浅的蓝色
  static const accentColor = Color(0xFFE6B800); // 暗金色

  late AnimationController _animController;
  late Animation<double> _opacityAnimation;

  bool _isRestoringPurchases = false;

  @override
  void initState() {
    super.initState();
    // 设置横屏
    SystemChrome.setPreferredOrientations([
      DeviceOrientation.landscapeLeft,
      DeviceOrientation.landscapeRight,
    ]);

    _loadAccountBalance();
    _shopManager.onPurchaseComplete = _handlePurchaseSuccess;
    _shopManager.onPurchaseError = _handlePurchaseFailure;
    _shopItems = _shopManager.getAvailableBundles();
    _loadProducts();

    _animController = AnimationController(
      duration: const Duration(milliseconds: 800),
      vsync: this,
    );

    _opacityAnimation = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(parent: _animController, curve: Curves.easeInOut),
    );

    _animController.forward();
  }

  @override
  void dispose() {
    // 恢复屏幕方向
    SystemChrome.setPreferredOrientations([
      DeviceOrientation.portraitUp,
      DeviceOrientation.portraitDown,
    ]);
    _animController.dispose();
    super.dispose();
  }

  Future<void> _loadProducts() async {
    setState(() {
      _isLoading = true;
    });

    try {
      await _shopManager.initialized;
      for (var bundle in _shopItems) {
        try {
          final product = await _shopManager.getProductDetails(bundle.itemId);
          setState(() {
            _productDetails[bundle.itemId] = product;
          });
        } catch (e) {
          print('Failed to load product ${bundle.itemId}: $e');
        }
      }
    } catch (e) {
      print('Failed to initialize shop: $e');
      _showResultMessage('Failed to load store: ${e.toString()}');
    } finally {
      setState(() {
        _isLoading = false;
      });
    }
  }

  Future<void> _loadAccountBalance() async {
    final prefs = await SharedPreferences.getInstance();
    setState(() {
      _coinBalance = prefs.getInt('accountGemBalance') ?? 6000;
    });
  }

  Future<void> _saveAccountBalance() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setInt('accountGemBalance', _coinBalance);
  }

  Future<void> deductGems(int amount) async {
    setState(() {
      _coinBalance = (_coinBalance - amount).clamp(0, double.infinity).toInt();
    });
    await _saveAccountBalance();
  }

  void _handlePurchaseSuccess(int purchasedAmount) {
    setState(() {
      _coinBalance += purchasedAmount;
      _saveAccountBalance();
    });
    _showResultMessage('Successfully added $purchasedAmount gems!');
  }

  void _handlePurchaseFailure(String errorMessage) {
    _showResultMessage('Transaction failed: $errorMessage');
  }

  void _showResultMessage(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(message)),
    );
  }

  Future<void> _handleRestorePurchases() async {
    setState(() {
      _isRestoringPurchases = true;
    });

    try {
      await _shopManager.recoverTransactions();
      _showResultMessage('Purchases restored successfully');
    } catch (e) {
      _showResultMessage('Failed to restore purchases: ${e.toString()}');
    } finally {
      setState(() {
        _isRestoringPurchases = false;
      });
    }
  }

  Future<void> _handlePurchase(LinstBundle bundle) async {
    if (_shopManager.isTransactionInProgress) {
      _showResultMessage(
          'Please wait for the current transaction to complete.');
      return;
    }

    setState(() {
      _isLoading = true;
    });

    try {
      final product = _productDetails[bundle.itemId];
      if (product == null) {
        _showResultMessage(
            'Product not available yet. Please try again later.');
        return;
      }
      await _shopManager.initiateTransaction(product);
    } catch (e) {
      _showResultMessage(e.toString());
    } finally {
      setState(() {
        _isLoading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: backgroundColor,
      body: Container(
        decoration: BoxDecoration(
          image: DecorationImage(
            image: AssetImage('assets/images/store_background.jpg'), // 需要添加背景图
            fit: BoxFit.cover,
            colorFilter: ColorFilter.mode(
              backgroundColor.withOpacity(0.7),
              BlendMode.darken,
            ),
          ),
        ),
        child: _isLoading
            ? const Center(
                child: CircularProgressIndicator(
                  valueColor: AlwaysStoppedAnimation<Color>(primaryColor),
                ),
              )
            : SafeArea(
                child: Column(
                  children: [
                    _buildGameStoreHeader(),
                    Expanded(
                      child: Row(
                        children: [
                          Expanded(
                            flex: 3,
                            child: _buildStoreContent(),
                          ),
                          _buildRightPanel(),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
      ),
    );
  }

  Widget _buildGameStoreHeader() {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 16),
      decoration: BoxDecoration(
        color: surfaceColor.withOpacity(0.8),
        border: Border(
          bottom: BorderSide(
            color: primaryColor.withOpacity(0.3),
            width: 2,
          ),
        ),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Row(
            children: [
              IconButton(
                icon: Icon(Icons.arrow_back_ios, color: primaryColor),
                onPressed: () => Navigator.of(context).pop(),
              ),
              const SizedBox(width: 16),
              const Text(
                '仙玉商城',
                style: TextStyle(
                  color: primaryColor,
                  fontSize: 24,
                  fontWeight: FontWeight.bold,
                  fontFamily: 'NotoSansTC', // 使用繁体中文字体
                ),
              ),
            ],
          ),
          _buildBalanceDisplay(),
        ],
      ),
    );
  }

  Widget _buildBalanceDisplay() {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 8),
      decoration: BoxDecoration(
        color: surfaceColor.withOpacity(0.6),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(
          color: primaryColor.withOpacity(0.5),
          width: 2,
        ),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Image.asset(
            'assets/images/coin_icon.png', // 需要添加仙玉图标
            width: 24,
            height: 24,
          ),
          const SizedBox(width: 8),
          Text(
            '$_coinBalance',
            style: const TextStyle(
              color: primaryColor,
              fontSize: 20,
              fontWeight: FontWeight.bold,
              fontFamily: 'NotoSansTC',
            ),
          ),
          const SizedBox(width: 8),
          const Text(
            '仙玉',
            style: TextStyle(
              color: Colors.white,
              fontSize: 16,
              fontFamily: 'NotoSansTC',
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildStoreContent() {
    return Container(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            '熱門商品',
            style: TextStyle(
              color: Colors.white,
              fontSize: 20,
              fontWeight: FontWeight.bold,
              fontFamily: 'NotoSansTC',
            ),
          ),
          const SizedBox(height: 16),
          Expanded(
            child: GridView.builder(
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 3,
                childAspectRatio: 0.75,
                crossAxisSpacing: 16,
                mainAxisSpacing: 16,
              ),
              itemCount: _shopItems.length,
              itemBuilder: (context, index) =>
                  _buildGameItemCard(_shopItems[index]),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildGameItemCard(LinstBundle bundle) {
    final product = _productDetails[bundle.itemId];
    final bool isAvailable = product != null;
    final bool isProcessing = _shopManager.isTransactionInProgress;

    return Container(
      decoration: BoxDecoration(
        color: surfaceColor.withOpacity(0.9),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color: primaryColor.withOpacity(0.3),
          width: 2,
        ),
        boxShadow: [
          BoxShadow(
            color: primaryColor.withOpacity(0.1),
            blurRadius: 10,
            spreadRadius: 1,
          ),
        ],
      ),
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          borderRadius: BorderRadius.circular(12),
          onTap: (isAvailable && !isProcessing)
              ? () => _handlePurchase(bundle)
              : null,
          child: Stack(
            children: [
              Padding(
                padding: const EdgeInsets.all(12),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    _buildItemIcon(bundle),
                    const SizedBox(height: 12),
                    Text(
                      bundle.name,
                      style: const TextStyle(
                        color: Colors.white,
                        fontSize: 16,
                        fontWeight: FontWeight.bold,
                        fontFamily: 'NotoSansTC',
                      ),
                      textAlign: TextAlign.center,
                    ),
                    const SizedBox(height: 8),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Image.asset(
                          'assets/images/coin_icon.png',
                          width: 20,
                          height: 20,
                        ),
                        const SizedBox(width: 4),
                        Text(
                          '${bundle.coinAmount}',
                          style: TextStyle(
                            color: primaryColor,
                            fontSize: 16,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 8),
                    Text(
                      '\$${product?.price ?? bundle.price}',
                      style: TextStyle(
                        color: Colors.white.withOpacity(0.8),
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                      ),
                      textAlign: TextAlign.center,
                    ),
                    const Spacer(),
                    _buildPurchaseButton(),
                  ],
                ),
              ),
              if (isProcessing)
                Positioned.fill(
                  child: Container(
                    decoration: BoxDecoration(
                      color: Colors.black.withOpacity(0.5),
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: const Center(
                      child: CircularProgressIndicator(
                        valueColor: AlwaysStoppedAnimation<Color>(primaryColor),
                      ),
                    ),
                  ),
                ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildItemIcon(LinstBundle bundle) {
    return Container(
      width: 64,
      height: 64,
      decoration: BoxDecoration(
        color: primaryColor.withOpacity(0.1),
        shape: BoxShape.circle,
        border: Border.all(
          color: primaryColor.withOpacity(0.5),
          width: 2,
        ),
      ),
      child: Icon(
        bundle.category == 'subscription'
            ? Icons.workspace_premium_rounded
            : Icons.diamond_rounded,
        color: primaryColor,
        size: 32,
      ),
    );
  }

  Widget _buildPurchaseButton() {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.symmetric(vertical: 8),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [
            primaryColor,
            accentColor,
          ],
        ),
        borderRadius: BorderRadius.circular(8),
        boxShadow: [
          BoxShadow(
            color: primaryColor.withOpacity(0.3),
            blurRadius: 4,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: const Text(
        '購買',
        style: TextStyle(
          color: Colors.black,
          fontSize: 16,
          fontWeight: FontWeight.bold,
          fontFamily: 'NotoSansTC',
        ),
        textAlign: TextAlign.center,
      ),
    );
  }

  Widget _buildRightPanel() {
    return Container(
      width: 200,
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: surfaceColor.withOpacity(0.8),
        border: Border(
          left: BorderSide(
            color: primaryColor.withOpacity(0.3),
            width: 2,
          ),
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            '特別優惠',
            style: TextStyle(
              color: Colors.white,
              fontSize: 18,
              fontWeight: FontWeight.bold,
              fontFamily: 'NotoSansTC',
            ),
          ),
          const SizedBox(height: 16),
          _buildPromotionCard(),
          const Spacer(),
          _buildRestorePurchasesButton(),
        ],
      ),
    );
  }

  Widget _buildPromotionCard() {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [
            primaryColor.withOpacity(0.2),
            accentColor.withOpacity(0.2),
          ],
        ),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color: primaryColor.withOpacity(0.5),
          width: 2,
        ),
      ),
      child: const Column(
        children: [
          Text(
            '首次充值雙倍',
            style: TextStyle(
              color: primaryColor,
              fontSize: 16,
              fontWeight: FontWeight.bold,
              fontFamily: 'NotoSansTC',
            ),
          ),
          SizedBox(height: 8),
          Text(
            '首次購買任意商品可獲得雙倍仙玉獎勵',
            style: TextStyle(
              color: Colors.white70,
              fontSize: 14,
              fontFamily: 'NotoSansTC',
            ),
            textAlign: TextAlign.center,
          ),
        ],
      ),
    );
  }

  Widget _buildRestorePurchasesButton() {
    return TextButton(
      onPressed: _isRestoringPurchases ? null : _handleRestorePurchases,
      style: TextButton.styleFrom(
        padding: const EdgeInsets.symmetric(vertical: 12),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          if (_isRestoringPurchases)
            const SizedBox(
              width: 16,
              height: 16,
              child: CircularProgressIndicator(
                strokeWidth: 2,
                valueColor: AlwaysStoppedAnimation<Color>(primaryColor),
              ),
            )
          else
            const Icon(Icons.restore, color: primaryColor),
          const SizedBox(width: 8),
          const Text(
            '恢復購買',
            style: TextStyle(
              color: primaryColor,
              fontSize: 14,
              fontFamily: 'NotoSansTC',
            ),
          ),
        ],
      ),
    );
  }
}
