import 'dart:math';
import 'package:flutter/material.dart';

class Upgrade {
  String id; // 唯一標識符
  String name; // 名稱
  String description; // 描述
  IconData icon; // 圖標
  String effect; // 效果類型
  double value; // 效果值
  String rarity; // 稀有度：common, uncommon, rare, epic, legendary
  int level; // 可升級次數
  int maxLevel; // 最大等級
  bool isTechnique; // 是否為特殊技術而非普通升級

  Upgrade({
    required this.id,
    required this.name,
    required this.description,
    required this.icon,
    required this.effect,
    required this.value,
    this.rarity = 'common',
    this.level = 1,
    this.maxLevel = 3,
    this.isTechnique = false,
  });

  // 獲取升級的品質顏色
  Color get rarityColor {
    switch (rarity) {
      case 'common':
        return Colors.grey.shade400;
      case 'uncommon':
        return Colors.green.shade400;
      case 'rare':
        return Colors.blue.shade400;
      case 'epic':
        return Colors.purple.shade400;
      case 'legendary':
        return Colors.orange.shade400;
      default:
        return Colors.grey.shade400;
    }
  }

  // 獲取升級的描述（包含等級信息）
  String getFullDescription() {
    if (maxLevel > 1) {
      return '$description (等級 $level/$maxLevel)';
    }
    return description;
  }

  // 獲取下一級的效果值
  double getNextLevelValue() {
    if (level >= maxLevel) return value;

    // 不同效果的成長曲線
    switch (effect) {
      case 'bolt_damage':
      case 'flame_damage':
      case 'frost_damage':
      case 'spirit_damage':
      case 'tornado_damage':
        return value * 1.5; // 傷害倍率隨等級提升50%

      case 'max_health':
      case 'cultivation_gain':
      case 'enlightenment_gain':
        return value * 1.3; // 生命值和經驗值倍率隨等級提升30%

      case 'health_regen':
      case 'fire_rate':
        return value * 1.2; // 恢復速度和攻擊速度隨等級提升20%

      case 'multi_shot':
      case 'damage_reflect':
        return value + 1; // 多重射擊和傷害反射線性增加

      default:
        return value * 1.2; // 默認提升20%
    }
  }

  // 升級到下一級
  Upgrade upgrade() {
    if (level >= maxLevel) return this;

    return Upgrade(
      id: id,
      name: name,
      description: description,
      icon: icon,
      effect: effect,
      value: getNextLevelValue(),
      rarity: rarity,
      level: level + 1,
      maxLevel: maxLevel,
      isTechnique: isTechnique,
    );
  }

  // 預設的升級選項列表
  static List<Upgrade> getDefaultOptions() {
    return [
      // 攻擊相關升級 - 基礎傷害提升
      Upgrade(
        id: 'bolt_damage',
        name: '紫霄神雷',
        description: '提升雷電子彈傷害50%',
        icon: Icons.bolt,
        effect: 'bolt_damage',
        value: 0.5,
        rarity: 'common',
        maxLevel: 5,
      ),
      Upgrade(
        id: 'flame_damage',
        name: '九陽真火',
        description: '提升火焰子彈傷害40%，灼燒效果傷害+2',
        icon: Icons.local_fire_department,
        effect: 'flame_damage',
        value: 0.4,
        rarity: 'uncommon',
        maxLevel: 4,
      ),
      Upgrade(
        id: 'frost_damage',
        name: '寒冰劍氣',
        description: '提升冰霜子彈傷害35%，減速效果提升10%',
        icon: Icons.ac_unit,
        effect: 'frost_damage',
        value: 0.35,
        rarity: 'uncommon',
        maxLevel: 4,
      ),
      Upgrade(
        id: 'spirit_damage',
        name: '元神之光',
        description: '提升靈氣子彈傷害45%，穿透額外一個敵人',
        icon: Icons.brightness_high,
        effect: 'spirit_damage',
        value: 0.45,
        rarity: 'rare',
        maxLevel: 3,
      ),
      Upgrade(
        id: 'tornado_damage',
        name: '風嘯九天',
        description: '提升風暴子彈傷害30%，擊退距離+30%',
        icon: Icons.air,
        effect: 'tornado_damage',
        value: 0.3,
        rarity: 'uncommon',
        maxLevel: 4,
      ),

      // 子彈解鎖升級
      Upgrade(
        id: 'flame_unlock',
        name: '赤炎心法',
        description: '解鎖火焰子彈，可造成持續傷害',
        icon: Icons.local_fire_department,
        effect: 'unlock_bullet',
        value: 0, // 特殊值，表示解鎖火焰子彈
        rarity: 'rare',
        maxLevel: 1,
      ),
      Upgrade(
        id: 'frost_unlock',
        name: '玄冰指',
        description: '解鎖冰霜子彈，可減緩敵人移動',
        icon: Icons.ac_unit,
        effect: 'unlock_bullet',
        value: 1, // 特殊值，表示解鎖冰霜子彈
        rarity: 'rare',
        maxLevel: 1,
      ),
      Upgrade(
        id: 'spirit_unlock',
        name: '靈氣凝聚',
        description: '解鎖靈氣子彈，可穿透多個敵人',
        icon: Icons.brightness_high,
        effect: 'unlock_bullet',
        value: 2, // 特殊值，表示解鎖靈氣子彈
        rarity: 'rare',
        maxLevel: 1,
      ),
      Upgrade(
        id: 'tornado_unlock',
        name: '風嘯術',
        description: '解鎖風暴子彈，可擊退敵人',
        icon: Icons.air,
        effect: 'unlock_bullet',
        value: 3, // 特殊值，表示解鎖風暴子彈
        rarity: 'rare',
        maxLevel: 1,
      ),

      // 防禦相關升級
      Upgrade(
        id: 'max_health',
        name: '玄龜靈鎧',
        description: '增加最大靈力值30%',
        icon: Icons.shield,
        effect: 'max_health',
        value: 0.3,
        rarity: 'uncommon',
        maxLevel: 5,
      ),
      Upgrade(
        id: 'health_regen',
        name: '氣回法',
        description: '每秒恢復1點靈力值',
        icon: Icons.favorite,
        effect: 'health_regen',
        value: 1,
        rarity: 'uncommon',
        maxLevel: 3,
      ),
      Upgrade(
        id: 'damage_reflect',
        name: '金光咒',
        description: '敵人攻擊時反彈30%傷害',
        icon: Icons.track_changes,
        effect: 'damage_reflect',
        value: 0.3,
        rarity: 'rare',
        maxLevel: 2,
      ),

      // 新增：防禦特殊技術
      Upgrade(
        id: 'invulnerable_time',
        name: '金鐘罩',
        description: '每次受到傷害後獲得1.5秒無敵時間',
        icon: Icons.security,
        effect: 'invulnerable_time',
        value: 1.5,
        rarity: 'epic',
        maxLevel: 1,
        isTechnique: true,
      ),
      Upgrade(
        id: 'life_steal',
        name: '吸星大法',
        description: '擊敗敵人回復2點靈力值',
        icon: Icons.favorite_border,
        effect: 'life_steal',
        value: 2,
        rarity: 'rare',
        maxLevel: 3,
      ),

      // 其他能力升級
      Upgrade(
        id: 'fire_rate',
        name: '疾風指',
        description: '提升攻擊速度20%',
        icon: Icons.speed,
        effect: 'fire_rate',
        value: 0.2,
        rarity: 'uncommon',
        maxLevel: 3,
      ),
      Upgrade(
        id: 'multi_shot',
        name: '分光化影',
        description: '同時發射額外一顆子彈',
        icon: Icons.looks_two,
        effect: 'multi_shot',
        value: 1,
        rarity: 'rare',
        maxLevel: 2,
      ),
      Upgrade(
        id: 'enlightenment_gain',
        name: '明心見性',
        description: '提升悟道進度獲取速度40%',
        icon: Icons.lightbulb,
        effect: 'enlightenment_gain',
        value: 0.4,
        rarity: 'uncommon',
        maxLevel: 3,
      ),
      Upgrade(
        id: 'cultivation_gain',
        name: '聚靈法陣',
        description: '提升修為獲取50%',
        icon: Icons.trending_up,
        effect: 'cultivation_gain',
        value: 0.5,
        rarity: 'uncommon',
        maxLevel: 4,
      ),

      // 新增：特殊技術類升級
      Upgrade(
        id: 'area_attack',
        name: '萬劍歸宗',
        description: '攻擊有15%機率對範圍內所有敵人造成傷害',
        icon: Icons.blur_circular,
        effect: 'area_attack',
        value: 0.15,
        rarity: 'legendary',
        maxLevel: 1,
        isTechnique: true,
      ),
      Upgrade(
        id: 'critical_strike',
        name: '太虛劍氣',
        description: '攻擊有25%機率造成雙倍傷害',
        icon: Icons.flash_on,
        effect: 'critical_strike',
        value: 0.25,
        rarity: 'epic',
        maxLevel: 2,
        isTechnique: true,
      ),
      Upgrade(
        id: 'bullet_homing',
        name: '神識鎖敵',
        description: '子彈具有追蹤效果，更容易命中敵人',
        icon: Icons.gps_fixed,
        effect: 'bullet_homing',
        value: 1.0,
        rarity: 'epic',
        maxLevel: 1,
        isTechnique: true,
      ),
      Upgrade(
        id: 'combo_mastery',
        name: '連擊精通',
        description: '連擊持續時間延長1秒，連擊獎勵提升20%',
        icon: Icons.repeat,
        effect: 'combo_mastery',
        value: 1.0,
        rarity: 'rare',
        maxLevel: 2,
        isTechnique: true,
      ),

      // 即時效果升級（僅出現在特定情況）
      Upgrade(
        id: 'health_small',
        name: '小團靈氣',
        description: '回復10點靈力值',
        icon: Icons.healing,
        effect: 'instant_health',
        value: 10,
        rarity: 'common',
        maxLevel: 1,
      ),
      Upgrade(
        id: 'health_large',
        name: '大團靈氣',
        description: '回復30點靈力值',
        icon: Icons.health_and_safety,
        effect: 'instant_health',
        value: 30,
        rarity: 'uncommon',
        maxLevel: 1,
      ),
      Upgrade(
        id: 'instant_enlightenment',
        name: '頓悟',
        description: '立即獲得30%悟道進度',
        icon: Icons.emoji_objects,
        effect: 'instant_enlightenment',
        value: 0.3,
        rarity: 'uncommon',
        maxLevel: 1,
      ),
    ];
  }

  // 隨機生成三個升級選項
  static List<Upgrade> generateUpgradeOptions(List<String> currentBullets,
      int playerLevel, List<String> acquiredUpgrades) {
    final allUpgrades = getDefaultOptions();
    final random = Random();
    final List<Upgrade> availableUpgrades = [];

    // 根據玩家等級調整不同稀有度升級出現的機率
    final double legendaryChance = min(0.05 + playerLevel * 0.003, 0.2);
    final double epicChance = min(0.1 + playerLevel * 0.005, 0.3);
    final double rareChance = min(0.2 + playerLevel * 0.008, 0.4);
    final double uncommonChance = min(0.4 + playerLevel * 0.01, 0.6);

    // 檢查玩家健康狀況，低於50%增加回復靈氣的機率
    final bool needsHealing = false; // 從GameState中獲取這個值

    // 已獲得的升級ID集合
    final acquiredUpgradeIds = Set<String>.from(acquiredUpgrades);

    // 篩選可用的升級選項
    for (final upgrade in allUpgrades) {
      // 對於已到達最大等級的升級，跳過
      if (acquiredUpgradeIds.contains(upgrade.id) &&
          upgrade.level >= upgrade.maxLevel) {
        continue;
      }

      // 對於解鎖子彈類型的升級，檢查是否已經擁有
      if (upgrade.effect == 'unlock_bullet') {
        final bulletTypes = ['flame', 'frost', 'spirit', 'tornado'];
        final index = upgrade.value.toInt();
        if (index >= 0 && index < bulletTypes.length) {
          final bulletType = bulletTypes[index];
          if (currentBullets.contains(bulletType)) {
            continue; // 已經擁有此子彈類型，跳過
          }
        }
      }

      // 根據稀有度和等級篩選
      final double rarityRoll = random.nextDouble();
      bool passRarityCheck = false;

      switch (upgrade.rarity) {
        case 'legendary':
          passRarityCheck = rarityRoll < legendaryChance;
          break;
        case 'epic':
          passRarityCheck = rarityRoll < epicChance;
          break;
        case 'rare':
          passRarityCheck = rarityRoll < rareChance;
          break;
        case 'uncommon':
          passRarityCheck = rarityRoll < uncommonChance;
          break;
        default: // common
          passRarityCheck = true;
          break;
      }

      // 透過稀有度檢查且不是已擁有的技術類型升級
      if (passRarityCheck &&
          !(upgrade.isTechnique && acquiredUpgradeIds.contains(upgrade.id))) {
        // 如果是已擁有的可升級項目，則創建下一級版本
        if (acquiredUpgradeIds.contains(upgrade.id)) {
          final nextLevelUpgrade = upgrade.upgrade();
          availableUpgrades.add(nextLevelUpgrade);
        } else {
          availableUpgrades.add(upgrade);
        }
      }
    }

    // 如果需要生命，增加回復選項的權重
    if (needsHealing) {
      final healingUpgrades = availableUpgrades
          .where(
              (u) => u.effect == 'instant_health' || u.effect == 'health_regen')
          .toList();

      // 重複添加來增加權重
      availableUpgrades.addAll(healingUpgrades);
    }

    // 隨機選擇三個不重複的升級選項
    final selectedUpgrades = <Upgrade>[];
    while (selectedUpgrades.length < 3 && availableUpgrades.isNotEmpty) {
      final index = random.nextInt(availableUpgrades.length);
      selectedUpgrades.add(availableUpgrades[index]);

      // 移除選中的升級和相同ID的其他升級（避免選到同一個升級的不同等級）
      availableUpgrades.removeWhere((u) => u.id == availableUpgrades[index].id);
    }

    // 如果可用升級不足三個，填充默認選項
    while (selectedUpgrades.length < 3) {
      selectedUpgrades.add(Upgrade(
        id: 'health_small',
        name: '小團靈氣',
        description: '回復10點靈力值',
        icon: Icons.healing,
        effect: 'instant_health',
        value: 10,
        rarity: 'common',
      ));
    }

    return selectedUpgrades;
  }

  // 將升級選項轉為JSON
  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'name': name,
      'description': description,
      'icon_code': icon.codePoint,
      'icon_font': icon.fontFamily,
      'effect': effect,
      'value': value,
      'rarity': rarity,
      'level': level,
      'max_level': maxLevel,
      'is_technique': isTechnique,
    };
  }

  // 從JSON創建升級選項
  factory Upgrade.fromJson(Map<String, dynamic> json) {
    return Upgrade(
      id: json['id'] as String,
      name: json['name'] as String,
      description: json['description'] as String,
      icon: IconData(
        json['icon_code'] as int,
        fontFamily: json['icon_font'] as String?,
      ),
      effect: json['effect'] as String,
      value: json['value'] as double,
      rarity: json['rarity'] as String? ?? 'common',
      level: json['level'] as int? ?? 1,
      maxLevel: json['max_level'] as int? ?? 3,
      isTechnique: json['is_technique'] as bool? ?? false,
    );
  }
}
