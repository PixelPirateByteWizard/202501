class GameLevel {
  final int levelNumber;
  final int colorCount;
  final int bottleCount;
  final int targetMoves;
  final String theme;

  const GameLevel({
    required this.levelNumber,
    required this.colorCount,
    required this.bottleCount,
    required this.targetMoves,
    this.theme = '化學實驗室',
  });

  static const List<GameLevel> levels = [
    GameLevel(levelNumber: 0, colorCount: 0, bottleCount: 0, targetMoves: 0), // Placeholder
    GameLevel(levelNumber: 1, colorCount: 2, bottleCount: 3, targetMoves: 2),
    GameLevel(levelNumber: 2, colorCount: 3, bottleCount: 4, targetMoves: 5),
    GameLevel(levelNumber: 3, colorCount: 3, bottleCount: 5, targetMoves: 7),
    GameLevel(levelNumber: 4, colorCount: 4, bottleCount: 5, targetMoves: 9),
    GameLevel(levelNumber: 5, colorCount: 4, bottleCount: 6, targetMoves: 12),
    GameLevel(levelNumber: 6, colorCount: 5, bottleCount: 7, targetMoves: 15),
    GameLevel(levelNumber: 7, colorCount: 5, bottleCount: 8, targetMoves: 18),
    GameLevel(levelNumber: 8, colorCount: 6, bottleCount: 8, targetMoves: 22),
    GameLevel(levelNumber: 9, colorCount: 6, bottleCount: 9, targetMoves: 25),
    GameLevel(levelNumber: 10, colorCount: 7, bottleCount: 10, targetMoves: 30),
  ];

  static GameLevel? getLevel(int levelNumber) {
    if (levelNumber < 1 || levelNumber >= levels.length) return null;
    return levels[levelNumber];
  }

  int calculateStars(int moveCount) {
    if (moveCount <= targetMoves) return 3;
    if (moveCount <= targetMoves + 3) return 2;
    return 1;
  }
}