import 'game_piece_model.dart';

/// Represents the definition for a single game level.
/// 代表单个游戏关卡的定义
class Level {
  final int levelNumber;
  final int moves;
  final Map<PieceColor, int> objectives;
  // You can extend this to include predefined obstacle layouts.
  // 你可以扩展这个类来包含预定义的障碍物布局
  // final List<ObstaclePlacement> obstacles;

  Level({
    required this.levelNumber,
    required this.moves,
    required this.objectives,
  });

  /// A static list of all available levels in the game.
  /// 游戏中所有可用关卡的静态列表
  static final List<Level> levels = [
    Level(
      levelNumber: 1,
      moves: 30,
      objectives: {
        PieceColor.green: 25,
        PieceColor.purple: 15,
      },
    ),
    // Add more levels here
    // 在这里添加更多关卡
    Level(
      levelNumber: 2,
      moves: 25,
      objectives: {
        PieceColor.orange: 20,
        PieceColor.green: 20,
      },
    ),
  ];
}
