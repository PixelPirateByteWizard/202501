import 'dart:math';
import 'package:flutter/material.dart';
import 'player.dart';
import 'enemy.dart';
import 'upgrade.dart';
import '../utils/game_utils.dart';

class GameState {
  Player player;
  List<Enemy> enemies;
  List<String> activeBullets;
  bool isPaused;
  bool isGameOver;
  int score;

  // 遊戲難度相關
  Duration enemySpawnInterval;
  double spawnRateMultiplier;

  // 額外屬性
  double healthRegenRate;
  double damageReflect;
  double fireRateMultiplier;
  int multiShotCount;
  double enlightenmentGainMultiplier;
  double cultivationGainMultiplier;
  Map<String, double> bulletDamageMultipliers;

  // 高級技能屬性
  bool isBulletHoming; // 子彈追踪效果
  double areaAttackChance; // 範圍攻擊觸發機率
  double criticalStrikeChance; // 暴擊機率
  int spiritBulletPierceCount; // 靈氣子彈穿透數量
  double flameBulletBurnDamage; // 火焰子彈額外灼燒傷害
  double frostBulletSlowFactor; // 冰霜子彈額外減速因子
  double tornadoBulletKnockbackFactor; // 風暴子彈額外擊退因子
  int lifeStealAmount; // 生命偷取量

  GameState({
    required this.player,
    required this.enemies,
    required this.activeBullets,
    this.isPaused = false,
    this.isGameOver = false,
    this.score = 0,
    required this.enemySpawnInterval,
    this.spawnRateMultiplier = 1.0,
    this.healthRegenRate = 0.0,
    this.damageReflect = 0.0,
    this.fireRateMultiplier = 1.0,
    this.multiShotCount = 1,
    this.enlightenmentGainMultiplier = 1.0,
    this.cultivationGainMultiplier = 1.0,
    required this.bulletDamageMultipliers,
    this.isBulletHoming = false,
    this.areaAttackChance = 0.0,
    this.criticalStrikeChance = 0.0,
    this.spiritBulletPierceCount = 1,
    this.flameBulletBurnDamage = 0.0,
    this.frostBulletSlowFactor = 0.0,
    this.tornadoBulletKnockbackFactor = 0.0,
    this.lifeStealAmount = 0,
  });

  // 創建新遊戲
  factory GameState.newGame([Player? initialPlayer]) {
    return GameState(
      player: initialPlayer ?? Player(),
      enemies: [],
      activeBullets: initialPlayer?.bullets ?? ['bolt'],
      enemySpawnInterval: GameConstants.enemySpawnInterval,
      bulletDamageMultipliers: {
        'bolt': 1.0,
        'flame': 1.0,
        'frost': 1.0,
        'spirit': 1.0,
        'tornado': 1.0,
      },
    );
  }

  // 檢查遊戲是否結束
  bool checkGameOver() {
    if (player.isDepleted) {
      isGameOver = true;
      return true;
    }
    return false;
  }

  // 更新敵人位置
  void updateEnemies(Size screenSize, Position characterPosition) {
    final activeEnemies = <Enemy>[];

    for (final enemy in enemies) {
      if (!enemy.isActive) continue;

      // 檢查是否與角色碰撞
      if (enemy.isCollidingWith(
          characterPosition, GameConstants.characterSize)) {
        // 對角色造成傷害
        player.takeDamage(enemy.damage);

        // 如果有傷害反射，對敵人造成反射傷害
        if (damageReflect > 0) {
          final reflectDamage = (enemy.damage * damageReflect).round();
          enemy.takeDamage(reflectDamage);
        }

        // 如果敵人仍然活躍（反射傷害後可能會死亡）
        if (enemy.isActive) {
          // 將敵人推開（模擬碰撞後的退後）
          final randomAngle = Random().nextDouble() * 2 * pi;
          enemy.position = Position(
            x: characterPosition.x +
                cos(randomAngle) * GameConstants.characterSize * 1.5,
            y: characterPosition.y +
                sin(randomAngle) * GameConstants.characterSize * 1.5,
          );
          activeEnemies.add(enemy);
        } else {
          // 敵人已被擊敗，增加分數
          score += enemy.reward;
          player.addCultivation(enemy.reward);
          player.addEnlightenment(GameConstants.baseEnlightenmentGain *
              enlightenmentGainMultiplier);
        }
      } else {
        // 敵人向角色移動
        enemy.moveTowardsCharacter(characterPosition);
        activeEnemies.add(enemy);
      }
    }

    enemies = activeEnemies;
  }

  // 生成新敵人
  void spawnEnemy(Size screenSize) {
    final enemy = Enemy.generateRandom(player.wave, screenSize);
    enemies.add(enemy);
  }

  // 更新遊戲難度
  void updateDifficulty() {
    // 根據波數調整敵人生成速度
    final baseInterval = GameConstants.enemySpawnInterval.inMilliseconds;

    // 計算波數修正因子，波數越高，生成間隔越短
    double waveModifier;

    if (player.wave <= 20) {
      // 前20波，每波減少2%生成間隔
      waveModifier = 1.0 - (player.wave * 0.02);
    } else if (player.wave <= 50) {
      // 20-50波，減少速度稍微放緩
      waveModifier = 0.6 - ((player.wave - 20) * 0.01); // 從0.6開始遞減
    } else {
      // 50波以上，最低不低於0.25倍基礎間隔
      waveModifier = 0.3 - ((player.wave - 50) * 0.001).clamp(0.0, 0.05);
      waveModifier = waveModifier.clamp(0.25, 0.3); // 確保不會低於0.25
    }

    // 計算新的敵人生成間隔，設置最小和最大限制
    final newInterval =
        (baseInterval * waveModifier).clamp(200, baseInterval).round();
    enemySpawnInterval = Duration(milliseconds: newInterval);

    // 計算生成率倍數，波數越高，敵人生成越多
    if (player.wave <= 20) {
      // 前20波，每波增加5%生成率
      spawnRateMultiplier = 1.0 + (player.wave * 0.05);
    } else if (player.wave <= 50) {
      // 20-50波，增加速度稍微加快
      spawnRateMultiplier = 2.0 + ((player.wave - 20) * 0.08);
    } else if (player.wave <= 100) {
      // 50-100波，進一步加速
      spawnRateMultiplier = 4.4 + ((player.wave - 50) * 0.1);
    } else {
      // 100波以上，指數級增加
      spawnRateMultiplier = 9.4 + (player.wave - 100) * 0.15;
    }

    // 每20波調整一次Boss出現頻率
    if (player.wave > 50) {
      // 高波數時，Boss更頻繁出現
      // 這裡沒有直接修改GameConstants.bossWaveInterval，而是通過在生成敵人時增加Boss概率來實現
      // 這個邏輯會在Enemy.generateRandom()方法中處理
    }
  }

  // 應用升級效果
  void applyUpgrade(Upgrade upgrade) {
    switch (upgrade.effect) {
      case 'bolt_damage':
        bulletDamageMultipliers['bolt'] =
            bulletDamageMultipliers['bolt']! + upgrade.value;
        break;
      case 'flame_damage':
        bulletDamageMultipliers['flame'] =
            bulletDamageMultipliers['flame']! + upgrade.value;
        flameBulletBurnDamage += 2; // 每級增加2點灼燒傷害
        break;
      case 'frost_damage':
        bulletDamageMultipliers['frost'] =
            bulletDamageMultipliers['frost']! + upgrade.value;
        frostBulletSlowFactor += 0.1; // 每級增加10%減速效果
        break;
      case 'spirit_damage':
        bulletDamageMultipliers['spirit'] =
            bulletDamageMultipliers['spirit']! + upgrade.value;
        spiritBulletPierceCount += 1; // 每級增加1個穿透目標
        break;
      case 'tornado_damage':
        bulletDamageMultipliers['tornado'] =
            bulletDamageMultipliers['tornado']! + upgrade.value;
        tornadoBulletKnockbackFactor += 0.3; // 每級增加30%擊退距離
        break;
      case 'unlock_bullet':
        final bulletTypes = ['flame', 'frost', 'spirit', 'tornado'];
        final index = upgrade.value.toInt();
        if (index >= 0 && index < bulletTypes.length) {
          final bulletType = bulletTypes[index];
          player.addBulletType(bulletType);
          activeBullets.add(bulletType);
        }
        break;
      case 'max_health':
        // 增加最大靈力值
        final currentHealth = player.health;
        final maxHealthIncrease = (player.maxHealth * upgrade.value).round();
        player.maxHealth += maxHealthIncrease;
        player.health = currentHealth + maxHealthIncrease;
        break;
      case 'health_regen':
        // 增加靈力值恢復速率
        healthRegenRate += upgrade.value;
        break;
      case 'damage_reflect':
        // 增加傷害反彈
        damageReflect += upgrade.value;
        break;
      case 'fire_rate':
        // 提升攻擊速度
        fireRateMultiplier += upgrade.value;
        break;
      case 'multi_shot':
        // 增加多重射擊數量
        multiShotCount += upgrade.value.toInt();
        break;
      case 'enlightenment_gain':
        // 提升悟道進度獲取速度
        enlightenmentGainMultiplier += upgrade.value;
        break;
      case 'cultivation_gain':
        // 提升修為獲取速度
        cultivationGainMultiplier += upgrade.value;
        break;
      case 'instant_health':
        // 立即恢復靈力值
        player.heal(upgrade.value.toInt());
        break;
      case 'area_attack':
        // 範圍攻擊技能
        areaAttackChance = upgrade.value;
        break;
      case 'critical_strike':
        // 暴擊技能
        criticalStrikeChance = upgrade.value;
        break;
      case 'bullet_homing':
        // 子彈追踪技能
        isBulletHoming = true;
        break;
      case 'life_steal':
        // 生命偷取技能
        lifeStealAmount = upgrade.value.toInt();
        break;
    }

    // 升級後重置悟道進度
    player.resetEnlightenment();
  }

  // 檢查升級是否生效
  String verifyUpgrade() {
    // 構建一個升級狀態的詳細信息字符串
    StringBuffer status = StringBuffer();

    // 基本信息
    status.writeln('=== 升級狀態檢查 ===');

    // 檢查子彈傷害
    status.writeln('\n子彈傷害倍率:');
    bulletDamageMultipliers.forEach((type, multiplier) {
      status.writeln('- $type: ${multiplier.toStringAsFixed(2)}x');
    });

    // 檢查子彈特殊效果
    status.writeln('\n子彈特殊效果:');
    status.writeln('- 火焰灼燒傷害: ${flameBulletBurnDamage.toStringAsFixed(1)}');
    status.writeln('- 冰霜減速因子: ${frostBulletSlowFactor.toStringAsFixed(2)}');
    status.writeln('- 靈氣穿透次數: $spiritBulletPierceCount');
    status.writeln(
        '- 風暴擊退因子: ${tornadoBulletKnockbackFactor.toStringAsFixed(2)}');

    // 檢查主動子彈類型
    status.writeln('\n已激活的子彈類型: ${activeBullets.join(', ')}');
    status.writeln('\n已解鎖的子彈類型: ${player.bullets.join(', ')}');

    // 檢查基本屬性
    status.writeln('\n基礎屬性:');
    status.writeln('- 攻擊速度: ${fireRateMultiplier.toStringAsFixed(2)}x');
    status.writeln('- 多重射擊數: $multiShotCount');
    status.writeln('- 子彈追蹤: ${isBulletHoming ? '已啟用' : '未啟用'}');
    status.writeln('- 範圍攻擊幾率: ${(areaAttackChance * 100).toStringAsFixed(1)}%');
    status
        .writeln('- 暴擊幾率: ${(criticalStrikeChance * 100).toStringAsFixed(1)}%');
    status.writeln('- 生命偷取: $lifeStealAmount');
    status.writeln('- 傷害反射: ${(damageReflect * 100).toStringAsFixed(1)}%');
    status.writeln('- 靈力恢復速率: ${healthRegenRate.toStringAsFixed(2)}/秒');

    // 檢查被動技能
    status.writeln('\n被動技能:');
    for (final skill in player.passiveSkills) {
      status.writeln('- $skill (等級 ${player.getPassiveSkillLevel(skill)})');
    }

    return status.toString();
  }

  // 每幀更新
  void update(double deltaTime, Size screenSize) {
    if (isPaused || isGameOver) return;

    // 角色位置（屏幕中心）
    final characterPosition = Position(
      x: screenSize.width / 2,
      y: screenSize.height / 2,
    );

    // 更新敵人位置
    updateEnemies(screenSize, characterPosition);

    // 靈力值恢復
    if (healthRegenRate > 0) {
      final healthToRegen = healthRegenRate * deltaTime;
      player.heal(healthToRegen.toInt());
    }

    // 更新連擊系統
    player.updateCombo((deltaTime * 1000).toInt());

    // 檢查遊戲是否結束
    checkGameOver();
  }

  // 將遊戲狀態轉為JSON
  Map<String, dynamic> toJson() {
    return {
      'player': player.toJson(),
      'enemies': enemies.map((e) => e.toJson()).toList(),
      'active_bullets': activeBullets,
      'is_paused': isPaused,
      'is_game_over': isGameOver,
      'score': score,
      'enemy_spawn_interval': enemySpawnInterval.inMilliseconds,
      'spawn_rate_multiplier': spawnRateMultiplier,
      'health_regen_rate': healthRegenRate,
      'damage_reflect': damageReflect,
      'fire_rate_multiplier': fireRateMultiplier,
      'multi_shot_count': multiShotCount,
      'enlightenment_gain_multiplier': enlightenmentGainMultiplier,
      'cultivation_gain_multiplier': cultivationGainMultiplier,
      'bullet_damage_multipliers': bulletDamageMultipliers,
      'is_bullet_homing': isBulletHoming,
      'area_attack_chance': areaAttackChance,
      'critical_strike_chance': criticalStrikeChance,
      'spirit_bullet_pierce_count': spiritBulletPierceCount,
      'flame_bullet_burn_damage': flameBulletBurnDamage,
      'frost_bullet_slow_factor': frostBulletSlowFactor,
      'tornado_bullet_knockback_factor': tornadoBulletKnockbackFactor,
      'life_steal_amount': lifeStealAmount,
    };
  }

  // 從JSON創建遊戲狀態
  factory GameState.fromJson(Map<String, dynamic> json) {
    return GameState(
      player: Player.fromJson(json['player'] as Map<String, dynamic>),
      enemies: (json['enemies'] as List)
          .map((e) => Enemy.fromJson(e as Map<String, dynamic>))
          .toList(),
      activeBullets: List<String>.from(json['active_bullets'] as List),
      isPaused: json['is_paused'] as bool,
      isGameOver: json['is_game_over'] as bool,
      score: json['score'] as int,
      enemySpawnInterval:
          Duration(milliseconds: json['enemy_spawn_interval'] as int),
      spawnRateMultiplier: json['spawn_rate_multiplier'] as double,
      healthRegenRate: json['health_regen_rate'] as double,
      damageReflect: json['damage_reflect'] as double,
      fireRateMultiplier: json['fire_rate_multiplier'] as double,
      multiShotCount: json['multi_shot_count'] as int,
      enlightenmentGainMultiplier:
          json['enlightenment_gain_multiplier'] as double,
      cultivationGainMultiplier: json['cultivation_gain_multiplier'] as double,
      bulletDamageMultipliers:
          Map<String, double>.from(json['bullet_damage_multipliers'] as Map),
      isBulletHoming: json['is_bullet_homing'] as bool? ?? false,
      areaAttackChance: json['area_attack_chance'] as double? ?? 0.0,
      criticalStrikeChance: json['critical_strike_chance'] as double? ?? 0.0,
      spiritBulletPierceCount: json['spirit_bullet_pierce_count'] as int? ?? 1,
      flameBulletBurnDamage: json['flame_bullet_burn_damage'] as double? ?? 0.0,
      frostBulletSlowFactor: json['frost_bullet_slow_factor'] as double? ?? 0.0,
      tornadoBulletKnockbackFactor:
          json['tornado_bullet_knockback_factor'] as double? ?? 0.0,
      lifeStealAmount: json['life_steal_amount'] as int? ?? 0,
    );
  }
}
