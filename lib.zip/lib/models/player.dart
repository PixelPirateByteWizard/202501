import '../utils/game_utils.dart';

class Player {
  int health; // 靈力值
  int maxHealth; // 最大靈力值
  int cultivationLevel; // 修為
  int wave; // 目前劫數
  int maxWave; // 最大劫數
  double enlightenmentProgress; // 悟道進度
  List<String> bullets; // 擁有的子彈類型
  String characterAsset; // 角色圖片路徑

  // 新增屬性
  String cultivationRealm; // 修煉境界
  List<String> passiveSkills; // 被動技能
  Map<String, int> skillLevels; // 技能等級

  // 連擊系統
  int comboCount; // 連擊數
  int comboTimer; // 連擊計時器
  double comboMultiplier; // 連擊倍率

  // 統計數據
  int totalEnemiesDefeated; // 已擊敗敵人總數
  int totalBosses; // 已擊敗Boss數
  int highestCombo; // 最高連擊數

  Player({
    this.health = 100,
    this.maxHealth = 100,
    this.cultivationLevel = 0,
    this.wave = 1,
    this.maxWave = 1, // 初始最大波數為1，允許無限進行
    this.enlightenmentProgress = 0.0,
    List<String>? bullets,
    String? characterAsset,
    String? cultivationRealm,
    List<String>? passiveSkills,
    Map<String, int>? skillLevels,
    this.comboCount = 0,
    this.comboTimer = 0,
    this.comboMultiplier = 1.0,
    this.totalEnemiesDefeated = 0,
    this.totalBosses = 0,
    this.highestCombo = 0,
  })  : bullets = bullets ?? ['bolt'],
        characterAsset =
            characterAsset ?? 'assets/images/characters/characters_1.png',
        cultivationRealm = cultivationRealm ?? '煉氣期',
        passiveSkills = passiveSkills ?? [],
        skillLevels = skillLevels ?? {};

  // 靈力值是否耗盡
  bool get isDepleted => health <= 0;

  // 是否可以升級
  bool get canLevelUp => enlightenmentProgress >= 1.0;

  // 獲取當前修煉境界
  String getCultivationRealm() {
    if (cultivationLevel < 100) {
      return '煉氣期';
    } else if (cultivationLevel < 300) {
      return '築基期';
    } else if (cultivationLevel < 600) {
      return '結丹期';
    } else if (cultivationLevel < 1000) {
      return '元嬰期';
    } else if (cultivationLevel < 2000) {
      return '化神期';
    } else if (cultivationLevel < 3500) {
      return '煉虛期';
    } else if (cultivationLevel < 5000) {
      return '大乘期';
    } else {
      return '渡劫期';
    }
  }

  // 更新修煉境界
  void updateCultivationRealm() {
    final newRealm = getCultivationRealm();
    if (newRealm != cultivationRealm) {
      cultivationRealm = newRealm;
      // 境界突破時可以解鎖新的被動技能
      unlockPassiveSkillsForRealm(newRealm);
    }
  }

  // 解鎖境界對應的被動技能
  void unlockPassiveSkillsForRealm(String realm) {
    switch (realm) {
      case '築基期':
        addPassiveSkill('靈力回復');
        break;
      case '結丹期':
        addPassiveSkill('靈氣護盾');
        break;
      case '元嬰期':
        addPassiveSkill('靈子感應');
        break;
      case '化神期':
        addPassiveSkill('五行相生');
        break;
      case '煉虛期':
        addPassiveSkill('天地共鳴');
        break;
      case '大乘期':
        addPassiveSkill('太虛劍意');
        break;
      case '渡劫期':
        addPassiveSkill('不滅金身');
        break;
    }
  }

  // 添加被動技能
  void addPassiveSkill(String skillName) {
    if (!passiveSkills.contains(skillName)) {
      passiveSkills.add(skillName);
      skillLevels[skillName] = 1;
    }
  }

  // 提升被動技能等級
  void upgradePassiveSkill(String skillName) {
    if (passiveSkills.contains(skillName)) {
      final currentLevel = skillLevels[skillName] ?? 1;
      skillLevels[skillName] = currentLevel + 1;
    }
  }

  // 獲取被動技能等級
  int getPassiveSkillLevel(String skillName) {
    return skillLevels[skillName] ?? 0;
  }

  // 更新連擊系統
  void updateCombo(int deltaTimeMs) {
    if (comboCount > 0) {
      comboTimer -= deltaTimeMs;
      if (comboTimer <= 0) {
        // 連擊中斷
        resetCombo();
      }
    }
  }

  // 增加連擊
  void incrementCombo() {
    comboCount++;
    if (comboCount > highestCombo) {
      highestCombo = comboCount;
    }

    // 重置連擊計時器
    comboTimer = GameConstants.comboTimeWindow;

    // 計算連擊倍率（有上限）
    comboMultiplier = 1.0 +
        minDouble(comboCount * 0.05, GameConstants.comboMultiplierMax - 1.0);
  }

  // 重置連擊
  void resetCombo() {
    comboCount = 0;
    comboTimer = 0;
    comboMultiplier = 1.0;
  }

  // 增加修為值
  void addCultivation(int amount) {
    // 應用連擊倍率
    final actualAmount = (amount * comboMultiplier).round();
    cultivationLevel += actualAmount;
    updateCultivationRealm();
  }

  // 增加悟道進度
  void addEnlightenment(double amount) {
    enlightenmentProgress += amount;
    if (enlightenmentProgress > 1.0) {
      enlightenmentProgress = 1.0;
    }
  }

  // 重置悟道進度（升級後）
  void resetEnlightenment() {
    enlightenmentProgress = 0.0;
  }

  // 受到傷害
  void takeDamage(int damage) {
    // 檢查是否有靈氣護盾技能
    if (passiveSkills.contains('靈氣護盾')) {
      final shieldLevel = getPassiveSkillLevel('靈氣護盾');
      final damageReduction = shieldLevel * 0.05; // 每級減少5%傷害
      damage = (damage * (1 - damageReduction)).round();
    }

    health -= damage;
    if (health < 0) {
      health = 0;
    }

    // 受到傷害時重置連擊
    resetCombo();
  }

  // 回復生命值
  void heal(int amount) {
    health += amount;
    if (health > maxHealth) {
      health = maxHealth;
    }
  }

  // 增加敵人擊敗計數
  void addEnemyDefeated(bool isBoss) {
    totalEnemiesDefeated++;
    if (isBoss) {
      totalBosses++;
    }
  }

  // 添加新子彈類型
  void addBulletType(String bulletType) {
    if (!bullets.contains(bulletType)) {
      bullets.add(bulletType);
    }
  }

  // 進入下一劫
  void nextWave() {
    wave++;
    if (wave > maxWave) {
      maxWave = wave;
    }
  }

  // 將玩家數據轉為JSON
  Map<String, dynamic> toJson() {
    return {
      'health': health,
      'max_health': maxHealth,
      'cultivation_level': cultivationLevel,
      'cultivation_realm': cultivationRealm,
      'wave': wave,
      'max_wave': maxWave,
      'enlightenment_progress': enlightenmentProgress,
      'bullets': bullets,
      'character_asset': characterAsset,
      'passive_skills': passiveSkills,
      'skill_levels': skillLevels,
      'combo_count': comboCount,
      'combo_timer': comboTimer,
      'combo_multiplier': comboMultiplier,
      'total_enemies_defeated': totalEnemiesDefeated,
      'total_bosses': totalBosses,
      'highest_combo': highestCombo,
    };
  }

  // 從JSON創建玩家
  factory Player.fromJson(Map<String, dynamic> json) {
    return Player(
      health: json['health'] as int,
      maxHealth: json['max_health'] as int? ?? 100,
      cultivationLevel: json['cultivation_level'] as int,
      cultivationRealm: json['cultivation_realm'] as String?,
      wave: json['wave'] as int,
      maxWave: json['max_wave'] as int,
      enlightenmentProgress: json['enlightenment_progress'] as double,
      bullets: List<String>.from(json['bullets'] as List),
      characterAsset: json['character_asset'] as String?,
      passiveSkills: json['passive_skills'] != null
          ? List<String>.from(json['passive_skills'] as List)
          : null,
      skillLevels: json['skill_levels'] != null
          ? Map<String, int>.from(json['skill_levels'] as Map)
          : null,
      comboCount: json['combo_count'] as int? ?? 0,
      comboTimer: json['combo_timer'] as int? ?? 0,
      comboMultiplier: json['combo_multiplier'] as double? ?? 1.0,
      totalEnemiesDefeated: json['total_enemies_defeated'] as int? ?? 0,
      totalBosses: json['total_bosses'] as int? ?? 0,
      highestCombo: json['highest_combo'] as int? ?? 0,
    );
  }
}

// 輔助函數
int min(int a, int b) {
  return a < b ? a : b;
}

double minDouble(double a, double b) {
  return a < b ? a : b;
}
