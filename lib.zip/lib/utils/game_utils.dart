import 'dart:math';
import 'package:flutter/material.dart';

// 位置類，用於跟蹤遊戲中物體的位置
class Position {
  double x;
  double y;

  Position({required this.x, required this.y});

  // 計算與另一個位置的距離
  double distanceTo(Position other) {
    final dx = x - other.x;
    final dy = y - other.y;
    return sqrt(dx * dx + dy * dy);
  }

  // 朝向目標位置移動指定距離
  void moveTowards(Position target, double distance) {
    final directionX = target.x - x;
    final directionY = target.y - y;
    final magnitude = sqrt(directionX * directionX + directionY * directionY);

    if (magnitude <= distance) {
      x = target.x;
      y = target.y;
    } else {
      x += (directionX / magnitude) * distance;
      y += (directionY / magnitude) * distance;
    }
  }

  // 將位置轉換為Offset（用於繪製）
  Offset toOffset() => Offset(x, y);

  // 建立一個副本
  Position copy() => Position(x: x, y: y);

  // 從JSON建立位置
  factory Position.fromJson(Map<String, dynamic> json) {
    return Position(
      x: json['x'] as double,
      y: json['y'] as double,
    );
  }

  // 轉換為JSON
  Map<String, dynamic> toJson() {
    return {
      'x': x,
      'y': y,
    };
  }
}

// 生成隨機位置（在屏幕邊緣）
Position generateRandomEnemyPosition(Size screenSize) {
  final random = Random();
  final side = random.nextInt(4); // 0=上, 1=右, 2=下, 3=左

  switch (side) {
    case 0: // 上
      return Position(
        x: random.nextDouble() * screenSize.width,
        y: 0,
      );
    case 1: // 右
      return Position(
        x: screenSize.width,
        y: random.nextDouble() * screenSize.height,
      );
    case 2: // 下
      return Position(
        x: random.nextDouble() * screenSize.width,
        y: screenSize.height,
      );
    case 3: // 左
      return Position(
        x: 0,
        y: random.nextDouble() * screenSize.height,
      );
    default:
      return Position(x: 0, y: 0);
  }
}

// 常量定義
class GameConstants {
  static const double characterSize = 60.0;
  static const double enemySize = 40.0;
  static const double bulletSize = 20.0;

  // 調整基礎敵人速度和子彈速度以優化遊戲節奏
  static const double baseEnemySpeed = 1.2;
  static const double bulletSpeed = 6.0;

  static const int baseEnemyHealth = 20;
  static const int baseEnemyDamage = 10;
  static const int baseBulletDamage = 12;

  // 提高基礎獎勵以加速初期遊戲進展
  static const int baseCultivationReward = 15;
  static const double baseEnlightenmentGain = 0.12;

  // 縮短敵人生成間隔以增加遊戲緊張感
  static const Duration enemySpawnInterval = Duration(milliseconds: 1800);
  static const Duration bulletFireInterval = Duration(milliseconds: 450);
  static const Duration gameTickInterval =
      Duration(milliseconds: 16); // ~60 FPS

  // 添加連擊系統常量
  static const int comboTimeWindow = 3000; // 連擊窗口（毫秒）
  static const double comboMultiplierMax = 2.0; // 最大連擊獎勵倍數

  // 關卡難度節奏控制
  static const int bossWaveInterval = 5; // 每5波出現一次Boss
  static const double waveScalingFactor = 0.15; // 每波難度增幅
  // 無最大波數限制，讓遊戲可以無限進行
  // static const int maxWaves = 30; // 最大波數（完整遊戲的長度）

  // 擊退效果
  static const double knockbackForce = 25.0; // 擊退力度

  // 無限模式難度調整
  static const double advancedWaveScalingBonus = 0.02; // 波數超過20後，每波額外增加2%難度
}

// 敵人類型定義
enum EnemyType {
  ghostFiend, // 鬼煞
  demonBeast, // 妖獸
  evilCultist, // 邪修
  undeadSoul, // 怨魂
  bossFiend // 魔王
}

// 子彈類型定義
enum BulletType {
  bolt, // 雷電
  flame, // 火焰
  frost, // 冰霜
  spirit, // 靈氣
  tornado // 風暴
}

// 從BulletType獲取圖標
IconData getBulletIcon(BulletType type) {
  switch (type) {
    case BulletType.bolt:
      return Icons.bolt;
    case BulletType.flame:
      return Icons.local_fire_department;
    case BulletType.frost:
      return Icons.ac_unit;
    case BulletType.spirit:
      return Icons.brightness_high;
    case BulletType.tornado:
      return Icons.air;
  }
}

// 從BulletType獲取顏色
Color getBulletColor(BulletType type) {
  switch (type) {
    case BulletType.bolt:
      return Colors.amber;
    case BulletType.flame:
      return Colors.deepOrange;
    case BulletType.frost:
      return Colors.lightBlue;
    case BulletType.spirit:
      return Colors.purple;
    case BulletType.tornado:
      return Colors.teal;
  }
}

// 從EnemyType獲取圖標
IconData getEnemyIcon(EnemyType type) {
  switch (type) {
    case EnemyType.ghostFiend:
      return Icons.face;
    case EnemyType.demonBeast:
      return Icons.pest_control;
    case EnemyType.evilCultist:
      return Icons.person;
    case EnemyType.undeadSoul:
      return Icons.warning;
    case EnemyType.bossFiend:
      return Icons.whatshot;
  }
}

// 從字符串獲取BulletType
BulletType bulletTypeFromString(String type) {
  switch (type) {
    case 'bolt':
      return BulletType.bolt;
    case 'flame':
      return BulletType.flame;
    case 'frost':
      return BulletType.frost;
    case 'spirit':
      return BulletType.spirit;
    case 'tornado':
      return BulletType.tornado;
    default:
      return BulletType.bolt;
  }
}

// 從字符串獲取EnemyType
EnemyType enemyTypeFromString(String type) {
  switch (type) {
    case 'ghostFiend':
      return EnemyType.ghostFiend;
    case 'demonBeast':
      return EnemyType.demonBeast;
    case 'evilCultist':
      return EnemyType.evilCultist;
    case 'undeadSoul':
      return EnemyType.undeadSoul;
    case 'bossFiend':
      return EnemyType.bossFiend;
    default:
      return EnemyType.ghostFiend;
  }
}

// 添加敵人特性獲取函數
Map<String, dynamic> getEnemyTraits(EnemyType type) {
  switch (type) {
    case EnemyType.ghostFiend:
      return {
        'name': '鬼煞',
        'description': '行動迅速但脆弱',
        'specialty': 'dodge', // 有機率閃避攻擊
        'specialtyChance': 0.2, // 20%機率觸發特性
      };
    case EnemyType.demonBeast:
      return {
        'name': '妖獸',
        'description': '強壯但緩慢',
        'specialty': 'armor', // 減少受到的傷害
        'specialtyChance': 0.3, // 30%傷害減免
      };
    case EnemyType.evilCultist:
      return {
        'name': '邪修',
        'description': '可召喚幻影分身',
        'specialty': 'summon', // 受到傷害時有機會召喚幻影
        'specialtyChance': 0.15, // 15%機率召喚幻影
      };
    case EnemyType.undeadSoul:
      return {
        'name': '怨魂',
        'description': '可穿透飛行',
        'specialty': 'phase', // 短時間無敵狀態
        'specialtyChance': 0.25, // 25%機率觸發短暫無敵
      };
    case EnemyType.bossFiend:
      return {
        'name': '魔王',
        'description': '強大且具有多種能力',
        'specialty': 'rage', // 生命值低時增加傷害
        'specialtyChance': 0.5, // 50%傷害增加當生命低於一半
      };
  }
}

// 子彈類型特效
Map<String, dynamic> getBulletSpecialEffects(BulletType type) {
  switch (type) {
    case BulletType.bolt:
      return {
        'name': '雷電',
        'effect': 'stun', // 暈眩效果
        'effectChance': 0.3, // 30%幾率觸發暈眩
        'effectDuration': 1000, // 暈眩持續1秒
      };
    case BulletType.flame:
      return {
        'name': '火焰',
        'effect': 'burn', // 灼燒效果
        'effectChance': 0.5, // 50%幾率觸發灼燒
        'effectDuration': 3000, // 持續傷害3秒
        'effectDamage': 3, // 每秒額外3點傷害
      };
    case BulletType.frost:
      return {
        'name': '冰霜',
        'effect': 'slow', // 減速效果
        'effectChance': 0.7, // 70%幾率觸發減速
        'effectDuration': 2000, // 減速持續2秒
        'effectValue': 0.5, // 速度減少50%
      };
    case BulletType.spirit:
      return {
        'name': '靈氣',
        'effect': 'pierce', // 穿透效果
        'effectChance': 1.0, // 100%穿透
        'pierceCount': 3, // 最多穿透3個敵人
      };
    case BulletType.tornado:
      return {
        'name': '風暴',
        'effect': 'knockback', // 擊退效果
        'effectChance': 0.8, // 80%幾率觸發擊退
        'effectValue': 1.5, // 擊退距離倍數
      };
  }
}

// 修練境界
enum CultivationLevel {
  mortal, // 凡人
  qi, // 煉氣期
  foundation, // 築基期
  core, // 金丹期
  nascent, // 元嬰期
  soul, // 化神期
  divinity, // 渡劫期
  ascension, // 飛升期
  immortal, // 仙人境
}

// 從字符串獲取修練境界
CultivationLevel cultivationLevelFromString(String level) {
  switch (level.toLowerCase()) {
    case 'qi':
      return CultivationLevel.qi;
    case 'foundation':
      return CultivationLevel.foundation;
    case 'core':
      return CultivationLevel.core;
    case 'nascent':
      return CultivationLevel.nascent;
    case 'soul':
      return CultivationLevel.soul;
    case 'divinity':
      return CultivationLevel.divinity;
    case 'ascension':
      return CultivationLevel.ascension;
    case 'immortal':
      return CultivationLevel.immortal;
    default:
      return CultivationLevel.mortal;
  }
}
