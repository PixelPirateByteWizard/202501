import 'package:flutter/material.dart';

class AppConstants {
  // 顏色常量
  static const Color primaryColor = Color(0xFFFBBF24); // 金色
  static const Color secondaryColor = Color(0xFF5B21B6); // 紫色
  static const Color backgroundColor = Color(0xFF1E3A8A); // 深藍色
  static const Color darkPurple = Color(0xFF3730A3); // 深紫色
  static const Color textColor = Colors.white;
  static const Color darkTextColor = Color(0xFF422006); // 深褐色

  // 漸變色配置
  static const LinearGradient primaryGradient = LinearGradient(
    colors: [Color(0xFFFBBF24), Color(0xFFF59E0B)], // 金色漸變
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );

  static const LinearGradient backgroundGradient = LinearGradient(
    colors: [Color(0xFF1E3A8A), Color(0xFF3730A3), Color(0xFF5B21B6)], // 藍紫漸變
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );

  static const LinearGradient startScreenGradient = LinearGradient(
    colors: [Color(0xFF064E3B), Color(0xFF065F46), Color(0xFF047857)], // 深綠色
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );

  static const LinearGradient upgradeScreenGradient = LinearGradient(
    colors: [Color(0xFF4A044E), Color(0xFF3B0764), Color(0xFF2A0A3B)], // 深紫色
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );

  static const LinearGradient gameOverScreenGradient = LinearGradient(
    colors: [Color(0xFF334155), Color(0xFF1E293B), Color(0xFF0F172A)], // 深沉灰藍
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );

  static const LinearGradient progressBarGradient = LinearGradient(
    colors: [Color(0xFFA78BFA), Color(0xFFFBBF24)], // 紫到金
    begin: Alignment.centerLeft,
    end: Alignment.centerRight,
  );

  // 文字樣式常量
  static const TextStyle headlineLarge = TextStyle(
    fontSize: 40,
    fontWeight: FontWeight.bold,
    color: primaryColor,
    shadows: [
      Shadow(
        color: Colors.black54,
        offset: Offset(1, 1),
        blurRadius: 3,
      ),
    ],
  );

  static const TextStyle headlineMedium = TextStyle(
    fontSize: 30,
    fontWeight: FontWeight.w600,
    color: primaryColor,
  );

  static const TextStyle titleLarge = TextStyle(
    fontSize: 18,
    fontWeight: FontWeight.bold,
    color: primaryColor,
  );

  static const TextStyle bodyLarge = TextStyle(
    fontSize: 16,
    color: textColor,
  );

  static const TextStyle bodyMedium = TextStyle(
    fontSize: 14,
    color: textColor,
  );

  // 邊框與形狀常量
  static final BorderRadius borderRadiusLarge = BorderRadius.circular(16);
  static final BorderRadius borderRadiusMedium = BorderRadius.circular(12);
  static final BorderRadius borderRadiusSmall = BorderRadius.circular(8);

  static const Border primaryBorder = Border.fromBorderSide(
    BorderSide(color: Color(0xFFFDE68A), width: 1),
  );

  // 動畫持續時間常量
  static const Duration animationDurationFast = Duration(milliseconds: 200);
  static const Duration animationDurationMedium = Duration(milliseconds: 500);
  static const Duration animationDurationSlow = Duration(milliseconds: 800);

  // 間距常量
  static const double paddingSmall = 8.0;
  static const double paddingMedium = 16.0;
  static const double paddingLarge = 24.0;
  static const double paddingExtraLarge = 32.0;

  // 大小常量
  static const double buttonHeight = 48.0;
  static const double buttonHeightSmall = 36.0;
  static const double iconSize = 24.0;
  static const double iconSizeLarge = 32.0;

  // 其他常量
  static const String appName = '仙途玄防';
  static const String appVersion = '1.0.0';
}
