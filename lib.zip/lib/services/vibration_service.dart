import 'package:vibration/vibration.dart';
import 'package:shared_preferences/shared_preferences.dart';

class VibrationService {
  static final VibrationService _instance = VibrationService._internal();
  factory VibrationService() => _instance;

  VibrationService._internal();

  // 振動狀態
  bool _vibrationEnabled = true;
  bool _hasVibrator = false;

  // 振動模式持續時間（毫秒）
  static const int _shortVibration = 20;
  static const int _mediumVibration = 50;
  static const int _longVibration = 100;
  static const int _patternVibration = 200;
  static const int _strongVibration = 80;

  // 初始化
  Future<void> init() async {
    try {
      // 檢查設備是否支持振動
      _hasVibrator = await Vibration.hasVibrator() ?? false;

      // 讀取用戶設置
      final prefs = await SharedPreferences.getInstance();
      _vibrationEnabled = prefs.getBool('vibrationEnabled') ?? true;
    } catch (e) {
      print('振動服務初始化錯誤: $e');
      _hasVibrator = false;
      _vibrationEnabled = false;
    }
  }

  // 設置振動狀態
  Future<void> setVibrationEnabled(bool enabled) async {
    _vibrationEnabled = enabled;
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool('vibrationEnabled', enabled);
  }

  // 獲取振動狀態
  bool get isVibrationEnabled => _vibrationEnabled && _hasVibrator;

  // 短振動（按鈕點擊）
  Future<void> shortVibrate() async {
    if (!isVibrationEnabled) return;
    try {
      await Vibration.vibrate(duration: _shortVibration);
    } catch (e) {
      print('振動錯誤: $e');
    }
  }

  // 中等振動（敵人擊中）
  Future<void> mediumVibrate() async {
    if (!isVibrationEnabled) return;
    try {
      await Vibration.vibrate(duration: _mediumVibration);
    } catch (e) {
      print('振動錯誤: $e');
    }
  }

  // 強烈振動（暴擊和範圍攻擊）
  Future<void> strongVibrate() async {
    if (!isVibrationEnabled) return;
    try {
      await Vibration.vibrate(
        duration: _strongVibration,
        amplitude: 255, // 最大强度
      );
    } catch (e) {
      print('振動錯誤: $e');
    }
  }

  // 長振動（遊戲結束）
  Future<void> longVibrate() async {
    if (!isVibrationEnabled) return;
    try {
      await Vibration.vibrate(duration: _longVibration);
    } catch (e) {
      print('振動錯誤: $e');
    }
  }

  // 震動模式（玩家受到傷害）
  Future<void> patternVibrate() async {
    if (!isVibrationEnabled) return;
    try {
      await Vibration.vibrate(
        pattern: [0, _patternVibration, 100, _patternVibration],
        intensities: [0, 128, 0, 255],
      );
    } catch (e) {
      print('振動錯誤: $e');
    }
  }

  // 升級振動模式
  Future<void> upgradeVibrate() async {
    if (!isVibrationEnabled) return;
    try {
      await Vibration.vibrate(
        pattern: [0, 50, 50, 100, 50, 150],
        intensities: [0, 100, 0, 200, 0, 255],
      );
    } catch (e) {
      print('振動錯誤: $e');
    }
  }
}
