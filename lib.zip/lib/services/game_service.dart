import 'dart:async';
import 'dart:math';
import 'package:flutter/material.dart';
import '../models/game_state.dart';
import '../models/enemy.dart';
import '../models/player.dart';
import '../models/upgrade.dart';
import '../utils/game_utils.dart';
import 'storage_service.dart';
import 'audio_service.dart';
import 'vibration_service.dart';

class GameService {
  // 遊戲狀態
  GameState? _gameState;
  GameState? get gameState => _gameState;

  // 定時器
  Timer? _gameLoopTimer;
  Timer? _enemySpawnTimer;
  Timer? _bulletFireTimer;

  // 畫面尺寸
  Size _screenSize = Size.zero;

  // 子彈列表
  final List<Map<String, dynamic>> _bullets = [];
  List<Map<String, dynamic>> get bullets => _bullets;

  // 音頻服務
  final AudioService _audioService = AudioService();

  // 振動服務
  final VibrationService _vibrationService = VibrationService();

  // 流式控制器，用於通知訂閱者更新
  final _gameStateController = StreamController<GameState>.broadcast();
  Stream<GameState> get gameStateStream => _gameStateController.stream;

  // 屏幕中心位置（角色位置）
  Position get characterPosition => Position(
        x: _screenSize.width / 2,
        y: _screenSize.height / 2,
      );

  // 初始化遊戲
  Future<void> initGame(Size screenSize, [Player? initialPlayer]) async {
    _screenSize = screenSize;

    // 初始化音頻服務
    await _audioService.init();

    // 初始化振動服務
    await _vibrationService.init();

    // 嘗試讀取已保存的遊戲狀態
    final savedGameState = await StorageService.loadGameState();

    if (savedGameState != null && !savedGameState.isGameOver) {
      _gameState = savedGameState;
    } else {
      // 創建新遊戲，可以選擇使用初始角色
      _gameState = GameState.newGame(initialPlayer);
    }

    _gameStateController.add(_gameState!);
  }

  // 開始遊戲循環
  void startGame() {
    if (_gameState == null) return;

    _gameState!.isPaused = false;
    _gameState!.isGameOver = false;

    // 播放遊戲音樂
    _audioService.playGameMusic();

    // 開始遊戲循環
    _startGameLoop();

    // 定時生成敵人
    _startEnemySpawner();

    // 定時發射子彈
    _startBulletFiring();

    _gameStateController.add(_gameState!);
  }

  // 暫停遊戲
  void pauseGame() {
    if (_gameState == null) return;

    _gameState!.isPaused = true;
    _stopTimers();

    // 暫停音樂
    _audioService.pauseAll();

    // 保存遊戲狀態
    StorageService.saveGameState(_gameState!);

    _gameStateController.add(_gameState!);
  }

  // 恢復遊戲
  void resumeGame() {
    if (_gameState == null) return;

    _gameState!.isPaused = false;

    // 恢復音樂
    _audioService.resumeAll();

    // 開始遊戲循環
    _startGameLoop();

    // 定時生成敵人
    _startEnemySpawner();

    // 定時發射子彈
    _startBulletFiring();

    _gameStateController.add(_gameState!);
  }

  // 結束遊戲
  void endGame() {
    if (_gameState == null) return;

    _gameState!.isGameOver = true;
    _stopTimers();

    // 播放遊戲結束音效
    _audioService.playSound('game_over');

    // 遊戲結束振動
    _vibrationService.longVibrate();

    // 保存玩家記錄
    StorageService.savePlayerRecord(_gameState!.player);

    // 清除已保存的遊戲狀態
    StorageService.clearGameState();

    _gameStateController.add(_gameState!);
  }

  // 重新開始遊戲
  void restartGame() {
    _stopTimers();
    _bullets.clear();

    // 創建新遊戲
    _gameState = GameState.newGame();

    // 播放按鈕音效
    _audioService.playSound('button_click');

    // 按鈕振動
    _vibrationService.shortVibrate();

    startGame();
  }

  // 返回主菜單
  void returnToMainMenu() {
    _stopTimers();
    _bullets.clear();

    // 停止遊戲音樂，播放菜單音樂
    _audioService.stopAll();
    _audioService.playMenuMusic();

    // 播放按鈕音效
    _audioService.playSound('button_click');

    // 按鈕振動
    _vibrationService.shortVibrate();

    // 清除已保存的遊戲狀態
    StorageService.clearGameState();

    // 創建新遊戲
    _gameState = GameState.newGame();
    _gameState!.isPaused = true;

    _gameStateController.add(_gameState!);
  }

  // 輸出升級狀態信息（用於調試）
  void printUpgradeStatus() {
    if (_gameState != null) {
      print(_gameState!.verifyUpgrade());
    }
  }

  // 選擇升級並應用
  void selectUpgrade(Upgrade upgrade) {
    // 輸出升級前狀態
    print("升級前：");
    printUpgradeStatus();

    _gameState?.applyUpgrade(upgrade);
    _gameState?.player.resetEnlightenment();
    _gameStateController.add(_gameState!);
    resumeGame();

    // 輸出升級後狀態
    print("升級後 (選擇了 ${upgrade.name})：");
    printUpgradeStatus();
  }

  // 開始遊戲循環
  void _startGameLoop() {
    _gameLoopTimer?.cancel();

    _gameLoopTimer = Timer.periodic(GameConstants.gameTickInterval, (timer) {
      if (_gameState == null) return;

      final deltaTime = GameConstants.gameTickInterval.inMilliseconds / 1000;

      // 更新遊戲狀態
      _gameState!.update(deltaTime, _screenSize);

      // 更新子彈位置
      _updateBullets(deltaTime);

      // 檢查遊戲是否結束
      if (_gameState!.checkGameOver()) {
        endGame();
        return;
      }

      _gameStateController.add(_gameState!);
    });
  }

  // 開始敵人生成器
  void _startEnemySpawner() {
    _enemySpawnTimer?.cancel();

    _enemySpawnTimer = Timer.periodic(_gameState!.enemySpawnInterval, (timer) {
      if (_gameState == null || _gameState!.isPaused || _gameState!.isGameOver)
        return;

      // 生成新敵人
      _gameState!.spawnEnemy(_screenSize);

      _gameStateController.add(_gameState!);
    });
  }

  // 開始子彈發射
  void _startBulletFiring() {
    _bulletFireTimer?.cancel();

    final fireInterval = GameConstants.bulletFireInterval.inMilliseconds /
        _gameState!.fireRateMultiplier;

    _bulletFireTimer =
        Timer.periodic(Duration(milliseconds: fireInterval.round()), (timer) {
      if (_gameState == null || _gameState!.isPaused || _gameState!.isGameOver)
        return;

      // 發射子彈
      _fireBullets();

      _gameStateController.add(_gameState!);
    });
  }

  // 發射子彈
  void _fireBullets() {
    if (_gameState == null || _gameState!.enemies.isEmpty) return;

    // 獲取所有活躍的敵人
    final activeEnemies = _gameState!.enemies.where((e) => e.isActive).toList();
    if (activeEnemies.isEmpty) return;

    // 為每種活躍的子彈類型發射子彈
    for (final bulletType in _gameState!.activeBullets) {
      for (var i = 0; i < _gameState!.multiShotCount; i++) {
        // 為每個子彈選擇一個不同的目標敵人，而不是所有子彈共用一個目標
        final random = Random();
        final targetEnemy = activeEnemies[random.nextInt(activeEnemies.length)];

        // 隨機偏移角度（適用於多重射擊）
        final angleOffset = (i - (_gameState!.multiShotCount - 1) / 2) * 0.2;

        final targetDirection = Position(
          x: targetEnemy.position.x - characterPosition.x,
          y: targetEnemy.position.y - characterPosition.y,
        );

        // 計算方向向量長度
        final distance = targetDirection.distanceTo(Position(x: 0, y: 0));

        // 標準化方向向量
        final normalizedDirection = Position(
          x: targetDirection.x / distance,
          y: targetDirection.y / distance,
        );

        // 應用角度偏移
        final angle =
            atan2(normalizedDirection.y, normalizedDirection.x) + angleOffset;
        final offsetDirection = Position(
          x: cos(angle),
          y: sin(angle),
        );

        // 創建子彈
        _createBullet(bulletType, offsetDirection);
      }
    }
  }

  // 創建子彈
  void _createBullet(String bulletType, Position direction) {
    final damage = (GameConstants.baseBulletDamage *
            (_gameState!.bulletDamageMultipliers[bulletType] ?? 1.0))
        .round();

    _bullets.add({
      'type': bulletType,
      'position': Position(
        x: characterPosition.x,
        y: characterPosition.y,
      ),
      'direction': direction,
      'damage': damage,
      'speed': GameConstants.bulletSpeed,
      'isActive': true,
    });
  }

  // 更新子彈位置
  void _updateBullets(double deltaTime) {
    final activeBullets = <Map<String, dynamic>>[];

    for (final bullet in _bullets) {
      if (!bullet['isActive']) continue;

      // 更新子彈位置
      final position = bullet['position'] as Position;
      final direction = bullet['direction'] as Position;
      final speed = bullet['speed'] as double;
      final bulletType = bullet['type'] as String;

      // 檢查是否為追蹤子彈
      final bool isHoming = _gameState!.isBulletHoming;

      if ((isHoming || bulletType == 'bolt') &&
          _gameState!.enemies.isNotEmpty) {
        // 尋找最近的敵人
        Enemy? closestEnemy;
        double minDistance = double.infinity;

        for (final enemy in _gameState!.enemies) {
          if (!enemy.isActive) continue;

          final distance = position.distanceTo(enemy.position);
          if (distance < minDistance) {
            minDistance = distance;
            closestEnemy = enemy;
          }
        }

        // 如果有敵人，稍微調整方向朝向敵人
        if (closestEnemy != null) {
          final targetDirection = Position(
            x: closestEnemy.position.x - position.x,
            y: closestEnemy.position.y - position.y,
          );

          // 計算距離
          final dist = sqrt(targetDirection.x * targetDirection.x +
              targetDirection.y * targetDirection.y);
          if (dist > 0) {
            // 標準化目標方向
            targetDirection.x /= dist;
            targetDirection.y /= dist;

            // 使用線性插值平滑地調整方向（子彈追蹤強度）
            // 為不同類型的子彈設置不同的追蹤強度
            double trackingStrength = 0.0;

            // 基礎追蹤子彈
            if (isHoming) {
              trackingStrength = 0.3; // 增強到0.3（原本是0.1）

              // 為不同類型的子彈增加特定追蹤力度
              switch (bulletType) {
                case 'bolt': // 雷電子彈具有較好的追蹤能力
                  trackingStrength = 0.4;
                  break;
                case 'spirit': // 靈氣子彈有極佳的追蹤能力
                  trackingStrength = 0.5;
                  break;
              }
            }
            // 即使沒有追蹤技能，雷電子彈也有基本的追蹤能力
            else if (bulletType == 'bolt') {
              trackingStrength = 0.15;
            }

            // 根據與敵人的距離調整追蹤強度，更近時追蹤更強
            if (minDistance < 100) {
              trackingStrength *= 1.5;
            }

            direction.x = direction.x * (1 - trackingStrength) +
                targetDirection.x * trackingStrength;
            direction.y = direction.y * (1 - trackingStrength) +
                targetDirection.y * trackingStrength;

            // 重新標準化方向
            final newDist =
                sqrt(direction.x * direction.x + direction.y * direction.y);
            if (newDist > 0) {
              direction.x /= newDist;
              direction.y /= newDist;
            }
          }
        }
      }

      position.x += direction.x * speed * deltaTime * 100;
      position.y += direction.y * speed * deltaTime * 100;

      // 檢查子彈是否超出屏幕範圍
      if (position.x < 0 ||
          position.x > _screenSize.width ||
          position.y < 0 ||
          position.y > _screenSize.height) {
        continue;
      }

      // 檢查子彈是否擊中敵人
      var hitEnemy = false;
      var hitCount = 0; // 用於靈氣子彈穿透次數

      // 檢查是否觸發範圍攻擊
      final bool isAreaAttack = bulletType == 'area' ||
          (Random().nextDouble() < _gameState!.areaAttackChance &&
              bulletType != 'area');

      // 如果是範圍攻擊，針對所有敵人
      if (isAreaAttack) {
        _performAreaAttack(position, bullet['damage'] as int);
        hitEnemy = true;
      } else {
        // 普通攻擊邏輯
        for (final enemy in _gameState!.enemies) {
          if (!enemy.isActive) continue;

          final distance = position.distanceTo(enemy.position);
          if (distance < GameConstants.enemySize / 2) {
            // 檢查暴擊
            int actualDamage = bullet['damage'] as int;
            bool isCritical =
                Random().nextDouble() < _gameState!.criticalStrikeChance;

            if (isCritical) {
              actualDamage = (actualDamage * 2).round(); // 暴擊雙倍傷害

              // 播放暴擊音效
              _audioService.playSound('critical_hit');

              // 強烈振動
              _vibrationService.strongVibrate();
            }

            // 子彈擊中敵人
            enemy.takeDamage(actualDamage);

            // 檢查子彈特殊效果
            _applyBulletEffects(bulletType, enemy);

            // 播放擊中音效
            _audioService.playSound(isCritical ? 'critical_hit' : 'bullet_hit');

            // 中等強度振動
            _vibrationService.mediumVibrate();

            // 如果敵人被擊敗
            if (!enemy.isActive) {
              _handleEnemyDefeated(enemy);
            }

            // 如果子彈是穿透類型（靈氣子彈），計數並檢查是否達到穿透上限
            if (bulletType == 'spirit') {
              hitCount++;

              // 獲取穿透最大數量，默認為1（只穿透一個敵人）
              final maxPierceCount = _gameState!.spiritBulletPierceCount;

              // 如果達到穿透上限，標記為擊中
              if (hitCount >= maxPierceCount) {
                hitEnemy = true;
                break;
              }
            } else {
              hitEnemy = true;
              break;
            }
          }
        }
      }

      if (!hitEnemy) {
        activeBullets.add(bullet);
      }
    }

    _bullets.clear();
    _bullets.addAll(activeBullets);
  }

  // 處理範圍攻擊
  void _performAreaAttack(Position center, int baseDamage) {
    // 範圍攻擊效果半徑
    const areaRadius = 100.0;

    // 播放範圍攻擊音效
    _audioService.playSound('area_attack');

    // 強烈振動
    _vibrationService.strongVibrate();

    // 對範圍內所有敵人造成傷害
    for (final enemy in _gameState!.enemies) {
      if (!enemy.isActive) continue;

      final distance = center.distanceTo(enemy.position);

      // 如果敵人在範圍內
      if (distance <= areaRadius) {
        // 依據距離計算衰減傷害（中心傷害最高）
        final damageFactor = 1.0 - (distance / areaRadius) * 0.5; // 邊緣處至少有50%傷害
        final actualDamage = (baseDamage * damageFactor).round();

        // 對敵人造成傷害
        enemy.takeDamage(actualDamage);

        // 應用擊退效果
        enemy.applyKnockback(center, GameConstants.knockbackForce);

        // 如果敵人被擊敗
        if (!enemy.isActive) {
          _handleEnemyDefeated(enemy);
        }
      }
    }

    // 添加視覺特效（在GameScreen處理）
    // TODO: 添加範圍攻擊視覺特效
  }

  // 應用子彈特殊效果
  void _applyBulletEffects(String bulletType, Enemy enemy) {
    switch (bulletType) {
      case 'bolt': // 雷電 - 暈眩效果
        if (Random().nextDouble() < 0.3) {
          // 30%幾率觸發暈眩
          enemy.setStunned(1000); // 1秒暈眩
        }
        break;

      case 'flame': // 火焰 - 灼燒效果
        if (Random().nextDouble() < 0.5) {
          // 50%幾率觸發灼燒
          // 計算灼燒傷害（基礎3點）
          final burnDamage = 3 + (_gameState!.flameBulletBurnDamage).round();
          enemy.setBurning(3000, burnDamage); // 3秒灼燒
        }
        break;

      case 'frost': // 冰霜 - 減速效果
        if (Random().nextDouble() < 0.7) {
          // 70%幾率觸發減速
          // 計算減速因子（基礎0.5，即速度減半）
          final slowFactor =
              0.5 - (_gameState!.frostBulletSlowFactor * 0.1); // 每級額外減速10%
          enemy.setSlowed(2000, slowFactor); // 2秒減速
        }
        break;

      case 'tornado': // 風暴 - 擊退效果
        if (Random().nextDouble() < 0.8) {
          // 80%幾率觸發擊退
          // 計算擊退力度（基礎力度加上額外因子）
          final knockbackForce = GameConstants.knockbackForce *
              (1.0 + _gameState!.tornadoBulletKnockbackFactor);

          // 從子彈到敵人的方向擊退
          final center = characterPosition;
          enemy.applyKnockback(center, knockbackForce);
        }
        break;
    }
  }

  // 處理敵人被擊敗邏輯
  void _handleEnemyDefeated(Enemy enemy) {
    // 播放敵人擊敗音效
    final isBoss = enemy.type == 'bossFiend';
    _audioService.playSound(isBoss ? 'boss_defeated' : 'enemy_defeated');

    // 增加分數
    _gameState!.score += enemy.reward;

    // 增加修為
    final cultivationReward =
        (enemy.reward * _gameState!.cultivationGainMultiplier).round();
    _gameState!.player.addCultivation(cultivationReward);

    // 增加悟道進度
    _gameState!.player.addEnlightenment(GameConstants.baseEnlightenmentGain *
        _gameState!.enlightenmentGainMultiplier);

    // 增加擊敗敵人計數
    _gameState!.player.addEnemyDefeated(isBoss);

    // 增加連擊
    _gameState!.player.incrementCombo();

    // 生命偷取效果
    if (_gameState!.lifeStealAmount > 0) {
      _gameState!.player.heal(_gameState!.lifeStealAmount);
    }

    // 如果是Boss被擊敗，進入下一波
    if (isBoss) {
      _gameState!.player.nextWave();
      _gameState!.updateDifficulty();
    }
  }

  // 停止所有定時器
  void _stopTimers() {
    _gameLoopTimer?.cancel();
    _enemySpawnTimer?.cancel();
    _bulletFireTimer?.cancel();
  }

  // 釋放資源
  void dispose() {
    _stopTimers();
    _gameStateController.close();
    _audioService.dispose();
  }

  // 設置振動狀態
  Future<void> setVibrationEnabled(bool enabled) async {
    await _vibrationService.setVibrationEnabled(enabled);
  }

  // 獲取振動狀態
  bool get isVibrationEnabled => _vibrationService.isVibrationEnabled;
}
