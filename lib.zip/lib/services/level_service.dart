import 'dart:math';
import 'package:flutter/material.dart';
import '../models/bottle.dart';
import '../models/game_level.dart';
import '../utils/colors.dart';
import '../utils/constants.dart';

class LevelService {
  static List<Bottle> generateLevel(GameLevel level, Size screenSize) {
    final bottles = <Bottle>[];
    
    // Create bottles
    for (int i = 0; i < level.bottleCount; i++) {
      bottles.add(Bottle(x: 0, y: 0));
    }
    
    // Create color pool
    final colorPool = <Color>[];
    for (int i = 0; i < level.colorCount; i++) {
      for (int j = 0; j < GameConstants.maxLiquid; j++) {
        colorPool.add(GameColors.liquidColors[i]);
      }
    }
    
    // Shuffle colors
    colorPool.shuffle(Random());
    
    // Fill bottles with mixed colors (only fill the first colorCount bottles)
    for (int i = 0; i < level.colorCount; i++) {
      for (int j = 0; j < GameConstants.maxLiquid; j++) {
        if (colorPool.isNotEmpty) {
          bottles[i].addLiquid(colorPool.removeLast());
        }
      }
    }
    
    // Position bottles
    _positionBottles(bottles, screenSize);
    
    return bottles;
  }
  
  static void _positionBottles(List<Bottle> bottles, Size screenSize) {
    final totalBottles = bottles.length;
    final bottlesPerRow = min(GameConstants.maxBottlesPerRow, 
        (screenSize.width / (GameConstants.bottleWidth + GameConstants.bottleSpacing)).floor());
    final rowCount = (totalBottles / bottlesPerRow).ceil();
    
    final totalWidth = bottlesPerRow * (GameConstants.bottleWidth + GameConstants.bottleSpacing) - GameConstants.bottleSpacing;
    final startX = (screenSize.width - totalWidth) / 2;
    final totalHeight = rowCount * (GameConstants.bottleHeight + 60) - 60;
    final startY = (screenSize.height - totalHeight) / 2 + 20;
    
    for (int i = 0; i < bottles.length; i++) {
      final row = i ~/ bottlesPerRow;
      final col = i % bottlesPerRow;
      
      bottles[i].x = startX + col * (GameConstants.bottleWidth + GameConstants.bottleSpacing);
      bottles[i].y = startY + row * (GameConstants.bottleHeight + 60);
    }
  }
  
  static void repositionBottles(List<Bottle> bottles, Size screenSize) {
    _positionBottles(bottles, screenSize);
  }
  
  static bool canPourLiquid(Bottle from, Bottle to) {
    if (from.isEmpty || to.isFull) return false;
    
    final topBlock = from.topBlock;
    if (to.isEmpty) return true;
    
    return to.topColor == topBlock.color && 
           (to.liquids.length + topBlock.amount) <= GameConstants.maxLiquid;
  }
  
  static bool isLevelComplete(List<Bottle> bottles) {
    return bottles.every((bottle) => bottle.isSorted);
  }
}