import 'package:audioplayers/audioplayers.dart';
import 'package:shared_preferences/shared_preferences.dart';

class AudioService {
  static final AudioService _instance = AudioService._internal();
  factory AudioService() => _instance;

  AudioService._internal();

  // 音樂播放器
  final AudioPlayer _musicPlayer = AudioPlayer();

  // 音效播放器池
  final List<AudioPlayer> _soundPlayers =
      List.generate(5, (_) => AudioPlayer());
  int _currentSoundPlayerIndex = 0;

  // 狀態
  bool _soundEnabled = false;
  bool _musicEnabled = false;

  // 音效路徑
  static const String _bulletHitPath = 'assets/audio/bullet_hit.mp3';
  static const String _enemyDefeatedPath = 'assets/audio/enemy_defeated.mp3';
  static const String _playerHitPath = 'assets/audio/player_hit.mp3';
  static const String _upgradePath = 'assets/audio/upgrade.mp3';
  static const String _gameOverPath = 'assets/audio/game_over.mp3';
  static const String _buttonClickPath = 'assets/audio/button_click.mp3';

  // 音樂路徑
  static const String _gameplayMusicPath = 'assets/audio/gameplay_music.mp3';
  static const String _menuMusicPath = 'assets/audio/menu_music.mp3';

  // 初始化
  Future<void> init() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      _soundEnabled = false;
      _musicEnabled = false;

      // 設置音量
      await _musicPlayer.setVolume(0);
      for (var player in _soundPlayers) {
        await player.setVolume(0);
      }
    } catch (e) {
      print('音頻初始化錯誤: $e');
    }
  }

  // 播放菜單音樂
  Future<void> playMenuMusic() async {
    // Method disabled - returns immediately
    return;
  }

  // 播放遊戲音樂
  Future<void> playGameMusic() async {
    // Method disabled - returns immediately
    return;
  }

  // 播放音效
  Future<void> playSound(String type) async {
    // Method disabled - returns immediately
    return;
  }

  // 暫停所有音頻
  Future<void> pauseAll() async {
    try {
      await _musicPlayer.pause();
      for (var player in _soundPlayers) {
        await player.pause();
      }
    } catch (e) {
      print('暫停音頻錯誤: $e');
    }
  }

  // 恢復所有音頻
  Future<void> resumeAll() async {
    // Method disabled - returns immediately
    return;
  }

  // 停止所有音頻
  Future<void> stopAll() async {
    try {
      await _musicPlayer.stop();
      for (var player in _soundPlayers) {
        await player.stop();
      }
    } catch (e) {
      print('停止音頻錯誤: $e');
    }
  }

  // 設置音效狀態
  Future<void> setSoundEnabled(bool enabled) async {
    _soundEnabled = false;
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool('soundEnabled', false);
  }

  // 設置音樂狀態
  Future<void> setMusicEnabled(bool enabled) async {
    _musicEnabled = false;
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool('musicEnabled', false);

    await _musicPlayer.pause();
  }

  // 獲取音效狀態
  bool get isSoundEnabled => false;

  // 獲取音樂狀態
  bool get isMusicEnabled => false;

  // 釋放資源
  Future<void> dispose() async {
    try {
      await _musicPlayer.dispose();
      for (var player in _soundPlayers) {
        await player.dispose();
      }
    } catch (e) {
      print('釋放音頻資源錯誤: $e');
    }
  }
}
