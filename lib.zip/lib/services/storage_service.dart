import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';
import '../models/game_state.dart';
import '../models/player.dart';

class StorageService {
  static const String _gameStateKey = 'xianxiataifang_game_state';
  static const String _highScoreKey = 'xianxiataifang_high_score';
  static const String _maxWaveKey = 'xianxiataifang_max_wave';
  static const String _settingsKey = 'xianxiataifang_settings';

  // 保存遊戲狀態
  static Future<bool> saveGameState(GameState gameState) async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final gameStateJson = json.encode(gameState.toJson());
      return await prefs.setString(_gameStateKey, gameStateJson);
    } catch (e) {
      print('保存遊戲狀態失敗: $e');
      return false;
    }
  }

  // 讀取遊戲狀態
  static Future<GameState?> loadGameState() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final gameStateJson = prefs.getString(_gameStateKey);

      if (gameStateJson == null) {
        return null;
      }

      final Map<String, dynamic> gameStateMap = json.decode(gameStateJson);
      return GameState.fromJson(gameStateMap);
    } catch (e) {
      print('讀取遊戲狀態失敗: $e');
      return null;
    }
  }

  // 清除已保存的遊戲狀態
  static Future<bool> clearGameState() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      return await prefs.remove(_gameStateKey);
    } catch (e) {
      print('清除遊戲狀態失敗: $e');
      return false;
    }
  }

  // 保存最高分數
  static Future<bool> saveHighScore(int score) async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final currentHighScore = prefs.getInt(_highScoreKey) ?? 0;

      if (score > currentHighScore) {
        return await prefs.setInt(_highScoreKey, score);
      }

      return true;
    } catch (e) {
      print('保存最高分數失敗: $e');
      return false;
    }
  }

  // 讀取最高分數
  static Future<int> loadHighScore() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      return prefs.getInt(_highScoreKey) ?? 0;
    } catch (e) {
      print('讀取最高分數失敗: $e');
      return 0;
    }
  }

  // 保存最高波數
  static Future<bool> saveMaxWave(int wave) async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final currentMaxWave = prefs.getInt(_maxWaveKey) ?? 0;

      if (wave > currentMaxWave) {
        return await prefs.setInt(_maxWaveKey, wave);
      }

      return true;
    } catch (e) {
      print('保存最高波數失敗: $e');
      return false;
    }
  }

  // 讀取最高波數
  static Future<int> loadMaxWave() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      return prefs.getInt(_maxWaveKey) ?? 0;
    } catch (e) {
      print('讀取最高波數失敗: $e');
      return 0;
    }
  }

  // 保存遊戲設置
  static Future<bool> saveSettings(Map<String, dynamic> settings) async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final settingsJson = json.encode(settings);
      return await prefs.setString(_settingsKey, settingsJson);
    } catch (e) {
      print('保存設置失敗: $e');
      return false;
    }
  }

  // 讀取遊戲設置
  static Future<Map<String, dynamic>> loadSettings() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final settingsJson = prefs.getString(_settingsKey);

      if (settingsJson == null) {
        // 返回默認設置
        return {
          'soundEnabled': true,
          'musicEnabled': true,
          'vibrationEnabled': true,
          'difficulty': 'normal', // easy, normal, hard
        };
      }

      return json.decode(settingsJson);
    } catch (e) {
      print('讀取設置失敗: $e');
      return {
        'soundEnabled': true,
        'musicEnabled': true,
        'vibrationEnabled': true,
        'difficulty': 'normal',
      };
    }
  }

  // 保存玩家記錄（包括高分和最高波數）
  static Future<bool> savePlayerRecord(Player player) async {
    try {
      await saveHighScore(player.cultivationLevel);
      await saveMaxWave(player.maxWave);
      return true;
    } catch (e) {
      print('保存玩家記錄失敗: $e');
      return false;
    }
  }
}
